document.addEventListener('DOMContentLoaded', function () {
    // Xóa sách trong dashboard
    document.querySelectorAll('.delete-book').forEach(button => {
        button.addEventListener('click', function() {
            const bookId = this.getAttribute('data-id');

            // Hiển thị hộp thoại xác nhận
            Swal.fire({
                title: 'Bạn có chắc chắn?',
                text: "Bạn có muốn xóa sách này không?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Có, xóa!',
                cancelButtonText: 'Hủy'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Gửi yêu cầu AJAX để xóa sách
                    fetch(`index.php?controller=user&action=deleteBook&id=${bookId}`, {
                        method: 'GET'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Xóa dòng khỏi bảng
                            document.querySelector(`tr[data-id="${bookId}"]`).remove();
                            Swal.fire(
                                'Đã xóa!',
                                data.success,
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'Lỗi!',
                                data.error || 'Không thể xóa sách.',
                                'error'
                            );
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire(
                            'Lỗi!',
                            'Đã xảy ra lỗi khi xóa sách.',
                            'error'
                        );
                    });
                }
            });
        });
    });

    // Xóa tài khoản
    const deleteUserButtons = document.querySelectorAll('.delete-user');
    deleteUserButtons.forEach(button => {
        button.addEventListener('click', function () {
            const userId = this.getAttribute('data-id');
            Swal.fire({
                title: 'Are you sure?',
                text: 'Do you want to delete this account?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#007bff',
                cancelButtonColor: '#dc3545',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`index.php?controller=user&action=deleteUser&id=${userId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: data.success,
                                    icon: 'success',
                                    confirmButtonColor: '#007bff',
                                    timer: 3000,
                                    timerProgressBar: true
                                });
                                const row = document.querySelector(`tr[data-user-id="${userId}"]`);
                                if (row) row.remove();
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: data.error,
                                    icon: 'error',
                                    confirmButtonColor: '#007bff'
                                });
                            }
                        })
                        .catch(() => {
                            Swal.fire({
                                title: 'Error!',
                                text: 'An error occurred, please try again.',
                                icon: 'error',
                                confirmButtonColor: '#007bff'
                            });
                        });
                }
            });
        });
    });

    // Hàm debounce để tránh gửi nhiều yêu cầu AJAX
    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    function updateCartItemCount(retries = 3, delay = 500) {
        const attempt = () => {
            fetch('index.php?controller=cart&action=getCartItemCount')
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    console.log('Cart Item Count:', data.count);
                    const cartLink = document.querySelector('a[href="index.php?controller=cart&action=index"]');
                    if (cartLink) {
                        let badge = cartLink.querySelector('.badge');
                        if (data.count > 0) {
                            if (!badge) {
                                badge = document.createElement('span');
                                badge.className = 'badge bg-primary rounded-pill';
                                cartLink.appendChild(badge);
                            }
                            badge.textContent = data.count;
                            badge.classList.add('animate__animated', 'animate__bounce');
                        } else if (badge) {
                            badge.remove();
                        }
                    } else {
                        console.error('Cart link not found');
                    }
                })
                .catch(error => {
                    console.error('Error updating cart item count:', error);
                    if (retries > 0) {
                        console.log(`Retrying... (${retries} attempts left)`);
                        setTimeout(() => attempt(), delay);
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Unable to update cart count.',
                            icon: 'error',
                            confirmButtonColor: '#007bff'
                        });
                    }
                });
        };
        attempt();
    }

    const debouncedUpdateCartItemCount = debounce(updateCartItemCount, 300);



    function isCartPage() {
        return window.location.href.includes('controller=cart&action=index');
    }

    function updateCartDisplay(cartItems, total) {
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTable = cartItemsContainer.closest('table');
        const totalElement = document.getElementById('cart-total');
        const checkoutButton = document.getElementById('checkout-button');

        if (cartItems.length === 0) {
            cartItemsContainer.innerHTML = '';
            cartTable.style.display = 'none';
            const emptyMessage = document.createElement('p');
            emptyMessage.className = 'text-center';
            emptyMessage.textContent = 'Giỏ hàng của bạn đang trống.';
            cartTable.insertAdjacentElement('afterend', emptyMessage);
            if (checkoutButton) checkoutButton.style.display = 'none';
            if (totalElement) totalElement.textContent = '0 VNĐ';
        } else {
            cartTable.style.display = '';
            if (checkoutButton) checkoutButton.style.display = '';
            const emptyMessage = cartTable.nextElementSibling;
            if (emptyMessage && emptyMessage.className === 'text-center') emptyMessage.remove();
            cartItemsContainer.innerHTML = cartItems.map(item => `
                <tr data-book-id="${item.book_id}">
                    <td>${item.image}</td>
                    <td>${item.title}</td>
                    <td>${item.author}</td>
                    <td class="text-danger">${Number(item.price).toLocaleString('vi-VN')} VNĐ</td>
                    <td>
                        <button class="btn btn-sm btn-outline-secondary decrease-quantity" data-id="${item.book_id}">-</button>
                        <span class="quantity mx-2">${item.quantity}</span>
                        <button class="btn btn-sm btn-outline-secondary increase-quantity" data-id="${item.book_id}">+</button>
                    </td>
                    <td class="subtotal text-danger">${Number(item.price * item.quantity).toLocaleString('vi-VN')} VNĐ</td>
                    <td>
                        <button class="btn btn-sm btn-danger remove-from-cart" data-id="${item.book_id}">Xóa</button>
                    </td>
                </tr>
            `).join('');
            if (totalElement) totalElement.textContent = Number(total).toLocaleString('vi-VN') + ' VNĐ';
        }
    }

    const increaseQuantityButtons = document.querySelectorAll('.increase-quantity');
    increaseQuantityButtons.forEach(button => {
        button.addEventListener('click', function () {
            const bookId = this.getAttribute('data-id');
            fetch(`index.php?controller=cart&action=increase&id=${bookId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            title: 'Success!',
                            text: data.success,
                            icon: 'success',
                            confirmButtonColor: '#007bff',
                            timer: 3000,
                            timerProgressBar: true
                        });
                        const row = document.querySelector(`tr[data-book-id="${bookId}"]`);
                        if (row) {
                            const quantityInput = row.querySelector('.quantity');
                            const subtotalCell = row.querySelector('.subtotal');
                            quantityInput.textContent = data.quantity;
                            if (isNaN(data.subtotal)) {
                                subtotalCell.textContent = 'Lỗi giá trị';
                            } else {
                                subtotalCell.textContent = Number(data.subtotal).toLocaleString('vi-VN') + ' VNĐ';
                            }
                            updateCartTotal();
                            debouncedUpdateCartItemCount();
                        }
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: data.error,
                            icon: 'error',
                            confirmButtonColor: '#007bff'
                        });
                    }
                })
                .catch(() => {
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred, please try again.',
                        icon: 'error',
                        confirmButtonColor: '#007bff'
                    });
                });
        });
    });

    const decreaseQuantityButtons = document.querySelectorAll('.decrease-quantity');
    decreaseQuantityButtons.forEach(button => {
        button.addEventListener('click', function () {
            const bookId = this.getAttribute('data-id');
            fetch(`index.php?controller=cart&action=decrease&id=${bookId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            title: 'Success!',
                            text: data.success,
                            icon: 'success',
                            confirmButtonColor: '#007bff',
                            timer: 3000,
                            timerProgressBar: true
                        });
                        const row = document.querySelector(`tr[data-book-id="${bookId}"]`);
                        if (row) {
                            if (data.cartEmpty || data.quantity === undefined) {
                                const cartItems = document.getElementById('cart-items');
                                cartItems.innerHTML = '';
                                const cartTable = cartItems.closest('table');
                                cartTable.style.display = 'none';
                                const emptyMessage = document.createElement('p');
                                emptyMessage.className = 'text-center';
                                emptyMessage.textContent = 'Giỏ hàng của bạn đang trống.';
                                cartTable.insertAdjacentElement('afterend', emptyMessage);
                                const checkoutButton = document.getElementById('checkout-button');
                                if (checkoutButton) checkoutButton.style.display = 'none';
                            } else {
                                const quantityInput = row.querySelector('.quantity');
                                const subtotalCell = row.querySelector('.subtotal');
                                quantityInput.textContent = data.quantity;
                                if (isNaN(data.subtotal)) {
                                    subtotalCell.textContent = 'Lỗi giá trị';
                                } else {
                                    subtotalCell.textContent = Number(data.subtotal).toLocaleString('vi-VN') + ' VNĐ';
                                }
                            }
                            updateCartTotal();
                            debouncedUpdateCartItemCount();
                        }
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: data.error,
                            icon: 'error',
                            confirmButtonColor: '#007bff'
                        });
                    }
                })
                .catch(() => {
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred, please try again.',
                        icon: 'error',
                        confirmButtonColor: '#007bff'
                    });
                });
        });
    });

    const removeFromCartButtons = document.querySelectorAll('.remove-from-cart');
    removeFromCartButtons.forEach(button => {
        button.addEventListener('click', function () {
            const bookId = this.getAttribute('data-id');
            Swal.fire({
                title: 'Are you sure?',
                text: 'Do you want to remove this item from your cart?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#007bff',
                cancelButtonColor: '#dc3545',
                confirmButtonText: 'Yes, remove it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`index.php?controller=cart&action=remove&id=${bookId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: data.success,
                                    icon: 'success',
                                    confirmButtonColor: '#007bff',
                                    timer: 3000,
                                    timerProgressBar: true
                                });
                                const row = document.querySelector(`tr[data-book-id="${bookId}"]`);
                                if (row) {
                                    row.remove();
                                    if (data.cartEmpty) {
                                        const cartItems = document.getElementById('cart-items');
                                        cartItems.innerHTML = '';
                                        const cartTable = cartItems.closest('table');
                                        cartTable.style.display = 'none';
                                        const emptyMessage = document.createElement('p');
                                        emptyMessage.className = 'text-center';
                                        emptyMessage.textContent = 'Giỏ hàng của bạn đang trống.';
                                        cartTable.insertAdjacentElement('afterend', emptyMessage);
                                        const checkoutButton = document.getElementById('checkout-button');
                                        if (checkoutButton) checkoutButton.style.display = 'none';
                                    }
                                    updateCartTotal();
                                    debouncedUpdateCartItemCount();
                                }
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: data.error,
                                    icon: 'error',
                                    confirmButtonColor: '#007bff'
                                });
                            }
                        })
                        .catch(() => {
                            Swal.fire({
                                title: 'Error!',
                                text: 'An error occurred, please try again.',
                                icon: 'error',
                                confirmButtonColor: '#007bff'
                            });
                        });
                }
            });
        });
    });

    const checkoutButton = document.getElementById('checkout-button');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function (e) {
            e.preventDefault();
            Swal.fire({
                title: 'Confirm Checkout',
                text: 'Are you sure you want to proceed with checkout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#28a745',
                cancelButtonColor: '#dc3545',
                confirmButtonText: 'Yes, checkout!',
                cancelButtonText: 'Cancel',
                animation: true,
                customClass: {
                    popup: 'animate__animated animate__fadeInDown'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.body.classList.add('animate__animated', 'animate__fadeOut');
                    setTimeout(() => {
                        window.location.href = 'index.php?controller=user&action=checkout';
                    }, 500);
                }
            });
        });
    }

    function updateCartTotal() {
        const rows = document.querySelectorAll('#cart-items tr');
        let total = 0;
        rows.forEach(row => {
            const subtotalText = row.querySelector('.subtotal').textContent.replace(/[^0-9.-]+/g, '').replace(/\./g, '');
            const subtotal = parseFloat(subtotalText);
            if (!isNaN(subtotal)) total += subtotal;
        });
        const totalElement = document.getElementById('cart-total');
        if (totalElement) {
            if (isNaN(total)) totalElement.textContent = 'Lỗi giá trị';
            else totalElement.textContent = total.toLocaleString('vi-VN') + ' VNĐ';
        }
    }

    const commentForm = document.getElementById('commentForm');
    if (commentForm) {
        commentForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch('index.php?controller=book&action=addComment', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    Swal.fire({
                        title: 'Error!',
                        text: data.error,
                        icon: 'error',
                        confirmButtonColor: '#007bff'
                    });
                } else {
                    Swal.fire({
                        title: 'Success!',
                        text: 'Your comment has been posted!',
                        icon: 'success',
                        confirmButtonColor: '#007bff',
                        timer: 3000,
                        timerProgressBar: true
                    });
                    const commentsSection = document.getElementById('commentsSection');
                    commentsSection.innerHTML = '';
                    data.forEach(comment => {
                        const commentDiv = document.createElement('div');
                        commentDiv.className = 'border p-3 mb-2 animate__animated animate__fadeIn';
                        commentDiv.innerHTML = `
                            <strong>${comment.full_name} (@${comment.username})</strong>
                            <small class="text-muted">${comment.created_at}</small>
                            <p>${comment.comment}</p>
                        `;
                        commentsSection.insertBefore(commentDiv, commentsSection.firstChild);
                    });
                    commentForm.reset();
                }
            });
        });
    }

    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    const searchResultsList = document.getElementById('search-results-list');
    const searchForm = document.getElementById('search-form');

    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const keyword = this.value.trim();
            if (keyword.length < 2) {
                searchResults.classList.remove('active');
                return;
            }

            fetch(`index.php?controller=book&action=search&keyword=${encodeURIComponent(keyword)}`)
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok: ' + response.statusText);
                    return response.json();
                })
                .then(data => {
                    console.log('Search results:', data); // Debugging: Log the response
                    if (data.error) {
                        Swal.fire({
                            title: 'Error!',
                            text: data.error,
                            icon: 'error',
                            confirmButtonColor: '#007bff'
                        });
                        return;
                    }
                    searchResultsList.innerHTML = '';
                    if (data.length === 0) {
                        searchResultsList.innerHTML = '<li class="dropdown-item text-muted">Không tìm thấy sách nào.</li>';
                    } else {
                        data.forEach(book => {
                            const li = document.createElement('li');
                            li.innerHTML = `
                                <a class="dropdown-item d-flex align-items-center" href="index.php?controller=book&action=show&id=${book.id}">
                                    <img src="${book.image}" alt="${book.title}" style="width: 40px; height: 40px; object-fit: cover; margin-right: 10px;">
                                    <div>
                                        <strong>${book.title}</strong><br>
                                        <small class="text-muted">${book.author}</small>
                                    </div>
                                </a>
                            `;
                            searchResultsList.appendChild(li);
                        });
                    }
                    searchResults.classList.add('active');
                })
                .catch(error => {
                    console.error('Search AJAX error:', error); // Debugging: Log any errors
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred, please try again.',
                        icon: 'error',
                        confirmButtonColor: '#007bff'
                    });
                });
        });

        searchForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const keyword = searchInput.value.trim();
            if (keyword.length >= 2) {
                window.location.href = `index.php?controller=book&action=searchResults&keyword=${encodeURIComponent(keyword)}`;
            } else {
                Swal.fire({
                    title: 'Invalid Input!',
                    text: 'Search term must be at least 2 characters.',
                    icon: 'warning',
                    confirmButtonColor: '#007bff'
                });
            }
        });

        document.addEventListener('click', function (e) {
            if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                searchResults.classList.remove('active');
            }
        });

        searchInput.addEventListener('focus', function () {
            if (this.value.trim().length >= 2) {
                searchResults.classList.add('active');
            }
        });
    }

    const searchAllInput = document.getElementById('search-all-input');
    const bookList = document.getElementById('book-list');
    const pagination = document.getElementById('pagination');
    const filterForm = document.getElementById('filter-form');
    const categoryCheckboxes = document.querySelectorAll('input[name="categories[]"]');
    const sortSelect = document.getElementById('sort-select');
    const clearFiltersButton = document.getElementById('clear-filters');
    const searchCount = document.getElementById('search-count');

    // const bookList = document.getElementById('book-list');
    // const searchCount = document.getElementById('search-count');
    // const pagination = document.getElementById('pagination');

    // Add to cart functionality
    function attachAddToCartEvents() {
        const addToCartButtons = document.querySelectorAll('.add-to-cart');
        addToCartButtons.forEach(button => {
            // Kiểm tra xem nút đã được gắn sự kiện chưa để tránh trùng lặp
            if (!button.hasAttribute('data-event-attached')) {
                button.setAttribute('data-event-attached', 'true');
                button.addEventListener('click', function (e) {
                    e.preventDefault();
                    const bookId = this.getAttribute('data-id');
                    fetch(`index.php?controller=cart&action=add&id=${bookId}`)
                        .then(response => {
                            if (!response.ok) throw new Error('Network response was not ok');
                            return response.json();
                        })
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: data.success,
                                    icon: 'success',
                                    confirmButtonColor: '#007bff',
                                    timer: 3000,
                                    timerProgressBar: true
                                });
                                debouncedUpdateCartItemCount();
                                if (isCartPage()) updateCartDisplay(data.cartItems, data.total);
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: data.error,
                                    icon: 'error',
                                    confirmButtonColor: '#007bff'
                                });
                            }
                        })
                        .catch(() => {
                            Swal.fire({
                                title: 'Error!',
                                text: 'An error occurred, please try again.',
                                icon: 'error',
                                confirmButtonColor: '#007bff'
                            });
                        });
                });
            }
        });
    }

    // Gắn sự kiện ban đầu khi trang được tải
    attachAddToCartEvents();

    // Hàm cập nhật danh sách sách
    function updateBookList(keyword, categories, sort, page) {
        const bookList = document.getElementById('book-list');
        const searchCount = document.getElementById('search-count');
        const pagination = document.getElementById('pagination');

        // Debugging: Log whether DOM elements are found
        console.log('DOM elements:', {
            bookList: bookList ? 'Found' : 'Not found',
            searchCount: searchCount ? 'Found' : 'Not found',
            pagination: pagination ? 'Found' : 'Not found'
        });

        // Check if required elements exist
        if (!bookList || !pagination) {
            console.error('Required DOM elements are missing:', { bookList, pagination });
            Swal.fire({
                title: 'Error!',
                text: 'Không thể tải sách: Thiếu các phần tử cần thiết trên trang.',
                icon: 'error',
                confirmButtonColor: '#007bff'
            });
            return;
        }

        const url = `index.php?controller=book&action=searchAll&keyword=${encodeURIComponent(keyword)}&categories=${encodeURIComponent(categories.join(','))}&sort=${encodeURIComponent(sort)}&page=${page}`;
        console.log('Fetching books with URL:', url);
        console.log('Parameters:', { keyword, categories, sort, page });

        fetch(url)
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) throw new Error(`Network response was not ok: ${response.status} ${response.statusText}`);
                return response.json();
            })
            .then(data => {
                console.log('Response data:', data);
                if (data.error) {
                    Swal.fire({
                        title: 'Error!',
                        text: data.error,
                        icon: 'error',
                        confirmButtonColor: '#007bff'
                    });
                    return;
                }
                bookList.innerHTML = '';
                if (data.books.length === 0) {
                    bookList.innerHTML = '<p class="text-center">Không tìm thấy sách nào.</p>';
                    if (searchCount) {
                        searchCount.textContent = 'Tìm thấy 0 sách';
                    }
                } else {
                    data.books.forEach(book => {
                        const bookDiv = document.createElement('div');
                        bookDiv.className = 'col-md-4 col-sm-6 mb-4 book-item animate__animated animate__fadeIn';
                        bookDiv.setAttribute('data-book-id', book.id);
                        bookDiv.innerHTML = `
                            <div class="card">
                                <img src="${book.image}" class="card-img-top" alt="${book.title}">
                                <div class="card-body">
                                    <h5 class="card-title">${book.title}</h5>
                                    <p class="card-text">Tác giả: ${book.author}</p>
                                    <p class="card-text text-muted">Thể loại: ${book.category_name}</p>
                                    <p class="card-text text-danger">${Number(book.price).toLocaleString('vi-VN')} VNĐ</p>
                                    <div class="d-flex gap-2">
                                        <a href="index.php?controller=book&action=show&id=${book.id}" class="btn btn-primary"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                                        <button class="btn btn-outline-secondary add-to-cart" data-id="${book.id}"><i class="bi bi-cart-plus-fill"></i></button>
                                    </div>
                                </div>
                            </div>
                        `;
                        bookList.appendChild(bookDiv);
                    });
                    if (searchCount) {
                        searchCount.textContent = `Tìm thấy ${data.books.length} sách`;
                    }
                }
                bookList.classList.add('animate__animated', 'animate__fadeInUp');

                // Gắn sự kiện "Add to Cart" cho các nút mới được tạo
                attachAddToCartEvents();

                // Debugging: Log pagination data
                console.log('Pagination data:', { currentPage: data.page, totalPages: data.totalPages });

                pagination.innerHTML = '';
                if (data.totalPages <= 0) {
                    console.warn('Total pages is 0 or negative, defaulting to 1 page');
                    data.totalPages = 1;
                }
                const ul = document.createElement('ul');
                ul.className = 'pagination justify-content-center';
                ul.innerHTML += `
                    <li class="page-item ${data.page <= 1 ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${data.page - 1}" aria-label="Previous">
                            <span aria-hidden="true">«</span>
                        </a>
                    </li>
                    <li class="page-item ${data.page == 1 ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="1">1</a>
                    </li>
                `;
                if (data.totalPages > 1) {
                    if (data.page > 3) {
                        ul.innerHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }
                    const start = Math.max(2, data.page - 1);
                    const end = Math.min(data.totalPages - 1, data.page + 1);
                    for (let i = start; i <= end; i++) {
                        ul.innerHTML += `
                            <li class="page-item ${data.page == i ? 'active' : ''}">
                                <a class="page-link" href="#" data-page="${i}">${i}</a>
                            </li>
                        `;
                    }
                    if (data.page < data.totalPages - 2) {
                        ul.innerHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }
                    ul.innerHTML += `
                        <li class="page-item ${data.page == data.totalPages ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${data.totalPages}">${data.totalPages}</a>
                        </li>
                    `;
                }
                ul.innerHTML += `
                    <li class="page-item ${data.page >= data.totalPages ? 'disabled' : ''}">
                        <a class="page-link" href="#" data-page="${data.page + 1}" aria-label="Next">
                            <span aria-hidden="true">»</span>
                        </a>
                    </li>
                `;
                pagination.appendChild(ul);
                pagination.querySelectorAll('.page-link').forEach(link => {
                    link.addEventListener('click', function (e) {
                        e.preventDefault();
                        const page = this.getAttribute('data-page');
                        if (page && !this.parentElement.classList.contains('disabled')) {
                            updateBookList(keyword, categories, sort, page);
                        }
                    });
                });
            })
            .catch(error => {
                console.error('Error loading books:', error);
                Swal.fire({
                    title: 'Error!',
                    text: 'An error occurred while loading books: ' + error.message,
                    icon: 'error',
                    confirmButtonColor: '#007bff'
                });
            });
    }

    if (searchAllInput) {
        let debounceTimeout;
        searchAllInput.addEventListener('input', function () {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(() => {
                const keyword = this.value.trim();
                const categories = Array.from(document.querySelectorAll('input[name="categories[]"]:checked')).map(input => input.value);
                const sort = document.querySelector('select[name="sort"]').value;
                const page = 1;
                updateBookList(keyword, categories, sort, page);
            }, 300);
        });
        categoryCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                const keyword = searchAllInput.value.trim();
                const categories = Array.from(document.querySelectorAll('input[name="categories[]"]:checked')).map(input => input.value);
                const sort = document.querySelector('select[name="sort"]').value;
                const page = 1;
                updateBookList(keyword, categories, sort, page);
            });
        });
        sortSelect.addEventListener('change', function () {
            const keyword = searchAllInput.value.trim();
            const categories = Array.from(document.querySelectorAll('input[name="categories[]"]:checked')).map(input => input.value);
            const sort = this.value;
            const page = 1;
            updateBookList(keyword, categories, sort, page);
        });
        filterForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const keyword = searchAllInput.value.trim();
            const categories = Array.from(document.querySelectorAll('input[name="categories[]"]:checked')).map(input => input.value);
            const sort = document.querySelector('select[name="sort"]').value;
            const page = 1;
            updateBookList(keyword, categories, sort, page);
        });
        clearFiltersButton.addEventListener('click', function () {
            searchAllInput.value = '';
            categoryCheckboxes.forEach(checkbox => checkbox.checked = false);
            sortSelect.value = 'title_asc';
            updateBookList('', [], 'title_asc', 1);
        });
    }


    // Toggle filter on mobile
    const toggleFilterBtn = document.getElementById('toggle-filter');
    const filterContent = document.querySelector('.filter-content');

    if (toggleFilterBtn && filterContent) {
        toggleFilterBtn.addEventListener('click', function () {
            filterContent.classList.toggle('show');
            toggleFilterBtn.classList.toggle('collapsed');
        });
    }

    // Checkbox effect
    const checkboxes = document.querySelectorAll('.filter-checkbox input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        // Kiểm tra trạng thái ban đầu
        const parent = checkbox.closest('.filter-checkbox');
        if (checkbox.checked) {
            parent.classList.add('checked');
        }

        // Thêm sự kiện change
        checkbox.addEventListener('change', function () {
            if (this.checked) {
                parent.classList.add('checked');
            } else {
                parent.classList.remove('checked');
            }
        });
    });
 
});
