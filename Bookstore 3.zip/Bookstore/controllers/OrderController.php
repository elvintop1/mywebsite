<?php

class OrderController {
    private $orderModel;

    public function __construct() {
        $this->orderModel = new Order();
    }

    // Hiển thị danh sách đơn hàng
    public function manage() {
        // Kiểm tra quyền truy cập
        if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        // Lấy danh sách đơn hàng
        $orders = $this->orderModel->getAllOrders();

        // Load view
        include 'views/admin/manage_orders.php';
    }

    // Hiển thị chi tiết đơn hàng
    public function detail() {
        // Kiểm tra quyền truy cập
        if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        // Kiểm tra ID đơn hàng
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
            $error = "ID đơn hàng không hợp lệ.";
            include 'views/admin/manage_orders.php';
            return;
        }

        $orderId = (int)$_GET['id'];
        $order = $this->orderModel->getOrderById($orderId);

        if (!$order) {
            $error = "Không tìm thấy đơn hàng.";
            include 'views/admin/manage_orders.php';
            return;
        }

        // Lấy danh sách sản phẩm trong đơn hàng
        $orderItems = $this->orderModel->getOrderItems($orderId);

        // Load view
        include 'views/admin/order_detail.php';
    }

    // Cập nhật trạng thái đơn hàng
    public function updateStatus() {
        // Kiểm tra quyền truy cập
        if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        // Kiểm tra dữ liệu gửi lên
        if (!isset($_GET['id']) || !is_numeric($_GET['id']) || !isset($_POST['status'])) {
            $error = "Dữ liệu không hợp lệ.";
            $orders = $this->orderModel->getAllOrders();
            include 'views/admin/manage_orders.php';
            return;
        }

        $orderId = (int)$_GET['id'];
        $status = $_POST['status'];

        // Kiểm tra trạng thái hợp lệ
        if (!in_array($status, ['pending', 'shipped', 'cancelled'])) {
            $error = "Trạng thái không hợp lệ.";
            $orders = $this->orderModel->getAllOrders();
            include 'views/admin/manage_orders.php';
            return;
        }

        // Cập nhật trạng thái đơn hàng
        $result = $this->orderModel->updateOrderStatus($orderId, $status);

        if ($result) {
            $success = "Cập nhật trạng thái đơn hàng thành công.";
        } else {
            $error = "Cập nhật trạng thái đơn hàng thất bại.";
        }

        // Load lại trang
        if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'detail') !== false) {
            $order = $this->orderModel->getOrderById($orderId);
            $orderItems = $this->orderModel->getOrderItems($orderId);
            include 'views/admin/order_detail.php';
        } else {
            $orders = $this->orderModel->getAllOrders();
            include 'views/admin/manage_orders.php';
        }
    }
}