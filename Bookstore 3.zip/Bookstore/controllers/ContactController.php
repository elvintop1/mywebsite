<?php
require_once 'models/Contact.php';

class ContactController {
    private $contactModel;

    public function __construct() {
        $this->contactModel = new Contact();
    }

    public function index() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            // $phone = $_POST['phone'];
            $message = $_POST['message'];
            if ($this->contactModel->saveContact($name, $email, $message)) {
                $success = "Tin nhắn của bạn đã được gửi thành công!";
            } else {
                $error = "Có lỗi xảy ra, vui lòng thử lại!";
            }
        }
        require_once 'views/contact/index.php';
    }

    public function manage() {
        if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin') {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 10; // Số liên hệ mỗi trang
        $contacts = $this->contactModel->getAllContacts($page, $limit);
        $totalContacts = $this->contactModel->getTotalContacts();
        $totalPages = ceil($totalContacts / $limit);
        require_once 'views/admin/manage_contacts.php';
    }
}
?>