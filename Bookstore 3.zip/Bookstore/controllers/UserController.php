<?php
require_once 'models/User.php';
require_once 'models/Order.php';
require_once 'models/Book.php';
require_once 'models/Category.php';

class UserController {
    private $userModel;
    private $orderModel;
    private $bookModel;
    private $categoryModel;

    public function __construct() {
        $this->userModel = new User();
        $this->orderModel = new Order();
        $this->bookModel = new Book();
        $this->categoryModel = new Category();
    }

    private function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            $full_name = $_POST['full_name'];
            $address = $_POST['address'] ?? null;
            $phone = $_POST['phone'] ?? null; 

            $userModel = new User();
            if ($userModel->register($username, $password, $email, $full_name, 'user', $address, $phone)) {
                $user = $userModel->login($username, $password);
                if ($user) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['success'] = "Đăng ký thành công! Bạn đã được đăng nhập.";
                    header("Location: index.php?controller=user&action=profile");
                    exit();
                } else {
                    $error = "Đăng ký thành công nhưng không thể đăng nhập. Vui lòng đăng nhập thủ công.";
                }
            } else {
                $error = "Đăng ký thất bại. Username hoặc email đã tồn tại.";
            }
        }
        include 'views/user/register.php';
    }
    
    public function updateUser($user_id) {
        $userModel = new User();
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $full_name = $_POST['full_name'];
            $role = $_POST['role'];
            $address = $_POST['address'] ?? null;
    
            if ($userModel->updateUser($user_id, $username, $email, $full_name, $role, $address)) {
                $success = "Cập nhật tài khoản thành công.";
            } else {
                $error = "Cập nhật tài khoản thất bại.";
            }
        }
        $user = $userModel->getUserById($user_id);
        include 'views/admin/edit_user.php';
    }

    public function login() {
        if ($this->isLoggedIn()) {
            if ($_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'admin') {
                header("Location: index.php?controller=user&action=dashboard");
            } else {
                header("Location: index.php?controller=user&action=profile");
            }
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $user = $this->userModel->login($username, $password);
            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['full_name'] = $user['full_name'];
                if ($_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'admin') {
                    header("Location: index.php?controller=user&action=dashboard");
                } else {
                    header("Location: index.php?controller=user&action=profile");
                }
            } else {
                $error = "Sai tên đăng nhập hoặc mật khẩu!";
                require_once 'views/user/login.php';
            }
        } else {
            require_once 'views/user/login.php';
        }
    }

    public function profile() {
        if (!$this->isLoggedIn()) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        if ($_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'admin') {
            header("Location: index.php?controller=user&action=dashboard");
            exit();
        }
        $orders = $this->userModel->getOrders($_SESSION['user_id']);
        require_once 'views/user/profile.php';
    }

    public function orderDetails($order_id) {
        if (!$this->isLoggedIn()) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        if ($_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'admin') {
            header("Location: index.php?controller=user&action=dashboard");
            exit();
        }
        $order = $this->userModel->getOrderById($order_id);
        if (!$order || $order['user_id'] != $_SESSION['user_id']) {
            $_SESSION['error'] = $order ? "Bạn không có quyền xem đơn hàng này." : "Đơn hàng không tồn tại.";
            header("Location: index.php?controller=user&action=profile");
            exit();
        }
        $orderDetails = $this->userModel->getOrderDetails($order_id);
        $orderNumber = isset($_GET['order_number']) ? (int)$_GET['order_number'] : 1;
        require_once 'views/user/order_details.php';
    }

    public function dashboard() {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        $limit = 10; 

        if (!empty($keyword)) {
            $books = $this->bookModel->searchBooks_admin($keyword, $page, $limit);
            $totalBooks = $this->bookModel->getTotalBooks($keyword);
        } else {
            $books = $this->bookModel->getAllBooks($page, $limit);
            $totalBooks = $this->bookModel->getTotalBooks();
        }

        $totalPages = ceil($totalBooks / $limit);
        require_once 'views/admin/dashboard.php';
    }

    public function manageUsers() {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 10; 
        if ($_SESSION['role'] == 'super_admin') {
            $users = $this->userModel->getAllUsers(null, $page, $limit);
            $totalUsers = $this->userModel->getTotalUsers();
        } else {
            $users = $this->userModel->getAllUsers('user', $page, $limit); 
            $totalUsers = $this->userModel->getTotalUsers('user');
        }
        $totalPages = ceil($totalUsers / $limit);
        require_once 'views/admin/manage_users.php';
    }

    public function addUser() {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            $full_name = $_POST['full_name'];
            $role = $_POST['role'];

            if ($_SESSION['role'] == 'admin' && $role != 'user') {
                $_SESSION['error'] = "Bạn không có quyền tạo tài khoản với vai trò này.";
                header("Location: index.php?controller=user&action=manageUsers");
                exit();
            }

            if ($this->userModel->register($username, $password, $email, $full_name, $role)) {
                $_SESSION['success'] = "Tài khoản đã được tạo thành công!";
                header("Location: index.php?controller=user&action=manageUsers");
            } else {
                $_SESSION['error'] = "Tên đăng nhập hoặc email đã tồn tại!";
                header("Location: index.php?controller=user&action=addUser");
            }
        } else {
            require_once 'views/admin/add_user.php';
        }
    }

    public function editUser($user_id) {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $user = $this->userModel->getUserById($user_id);
        if (!$user) {
            $_SESSION['error'] = "Tài khoản không tồn tại.";
            header("Location: index.php?controller=user&action=manageUsers");
            exit();
        }
        if ($_SESSION['role'] == 'admin' && $user['role'] != 'user') {
            $_SESSION['error'] = "Bạn không có quyền sửa tài khoản này.";
            header("Location: index.php?controller=user&action=manageUsers");
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            error_log("UpdateUser POST data: " . print_r($_POST, true)); 
            $username = $_POST['username'];
            $email = $_POST['email'];
            $full_name = $_POST['full_name'];
            $role = $_POST['role'];
            $address = $_POST['address'] ?? null; 

            if ($_SESSION['role'] == 'admin' && $role != 'user') {
                $error = "Bạn không có quyền thay đổi vai trò này.";
            } else {
                if ($this->userModel->checkDuplicate($username, $email, $user_id)) {
                    $error = "Username hoặc email đã tồn tại.";
                } else {
                    if ($this->userModel->updateUser($user_id, $username, $email, $full_name, $role, $address)) {
                        $_SESSION['success'] = "Tài khoản đã được cập nhật thành công!";
                        header("Location: index.php?controller=user&action=manageUsers");
                        exit();
                    } else {
                        $error = "Có lỗi xảy ra, vui lòng thử lại. Kiểm tra log để biết thêm chi tiết.";
                    }
                }
            }
        }
        require_once 'views/admin/edit_user.php';
    }

    public function deleteUser($user_id) {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            echo json_encode(['error' => 'Bạn cần đăng nhập với vai trò Admin hoặc Super Admin.']);
            exit();
        }
        $user = $this->userModel->getUserById($user_id);
        if (!$user) {
            echo json_encode(['error' => 'Tài khoản không tồn tại.']);
            exit();
        }
        if ($_SESSION['role'] == 'admin' && $user['role'] != 'user') {
            echo json_encode(['error' => 'Bạn không có quyền xóa tài khoản này.']);
            exit();
        }
        if ($user_id == $_SESSION['user_id']) {
            echo json_encode(['error' => 'Bạn không thể xóa tài khoản của chính mình.']);
            exit();
        }
        if ($this->userModel->deleteUser($user_id)) {
            echo json_encode(['success' => 'Tài khoản đã được xóa thành công!']);
        } else {
            echo json_encode(['error' => 'Có lỗi xảy ra, vui lòng thử lại.']);
        }
        exit();
    }


    public function updateProfile() {
        if (!$this->isLoggedIn()) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        if ($_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'admin') {
            header("Location: index.php?controller=user&action=dashboard");
            exit();
        }
        $user_id = $_SESSION['user_id'];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            error_log("UpdateProfile POST data: " . print_r($_POST, true)); 
            $email = $_POST['email'];
            $full_name = $_POST['full_name'];

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['error'] = "Email không hợp lệ.";
                header("Location: index.php?controller=user&action=profile");
                exit();
            }

            if ($this->userModel->checkDuplicate($_SESSION['username'], $email, $user_id)) {
                $_SESSION['error'] = "Email đã tồn tại.";
                header("Location: index.php?controller=user&action=profile");
                exit();
            }

            if ($this->userModel->updateProfile($user_id, $email, $full_name)) {
                $_SESSION['email'] = $email;
                $_SESSION['full_name'] = $full_name;
                $_SESSION['success'] = "Cập nhật hồ sơ thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra, vui lòng thử lại. Kiểm tra log để biết thêm chi tiết.";
            }
        }
        header("Location: index.php?controller=user&action=profile");
        exit();
    }

    public function addBook() {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $price = $_POST['price'];
            $description = $_POST['description'];
            $category_id = $_POST['category_id'];
            $image = $_FILES['image']['name'];
            move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $image);
            $this->bookModel->addBook($title, $author, $price, $image, $description, $category_id);
            header("Location: index.php?controller=user&action=dashboard");
        }
        $categories = $this->categoryModel->getAllCategories();
        require_once 'views/admin/add_book.php';
    }

    public function editBook($id) {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $book = $this->bookModel->getBookById($id);
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $price = $_POST['price'];
            $description = $_POST['description'];
            $category_id = $_POST['category_id'];
            $image = $_FILES['image']['name'] ? $_FILES['image']['name'] : $book['image'];
            if ($_FILES['image']['name']) {
                move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $image);
            }
            $this->bookModel->updateBook($id, $title, $author, $price, $image, $description, $category_id);
            header("Location: index.php?controller=user&action=dashboard");
        }
        $categories = $this->categoryModel->getAllCategories();
        require_once 'views/admin/edit_book.php';
    }

    public function deleteBook($id) {
        if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'super_admin')) {
            echo json_encode(['error' => 'Bạn không có quyền xóa sách.']);
            exit();
        }
    
        $bookModel = new Book();
        $result = $bookModel->deleteBook($id);
        if ($result) {
            echo json_encode(['success' => 'Xóa sách thành công.']);
        } else {
            echo json_encode(['error' => 'Xóa sách thất bại.']);
        }
        exit();
    }

    public function manageCategories() {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $categories = $this->categoryModel->getAllCategories();
        require_once 'views/admin/manage_categories.php';
    }

    public function addCategory() {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $this->categoryModel->addCategory($name);
            header("Location: index.php?controller=user&action=manageCategories");
        }
        require_once 'views/admin/add_category.php';
    }

    public function editCategory($id) {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $category = $this->categoryModel->getCategoryById($id);
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $this->categoryModel->updateCategory($id, $name);
            header("Location: index.php?controller=user&action=manageCategories");
        }
        require_once 'views/admin/edit_category.php';
    }

    public function deleteCategory($id) {
        if (!$this->isLoggedIn() || ($_SESSION['role'] != 'super_admin' && $_SESSION['role'] != 'admin')) {
            header("Location: index.php?controller=user&action=login");
            exit();
        }
        $category = $this->categoryModel->getCategoryById($id);
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->categoryModel->deleteCategory($id);
            header("Location: index.php?controller=user&action=manageCategories");
        }
        require_once 'views/admin/delete_category.php';
    }

    public function logout() {
        session_destroy();
        header("Location: index.php?controller=user&action=login");
    }

    public function checkout() {
        // Kiểm tra đăng nhập
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $bookModel = new Book(); // Sử dụng Book thay vì Cart
        $cartItems = $bookModel->getCartItems($user_id);

        if (empty($cartItems)) {
            $error = "Giỏ hàng trống.";
            include 'views/cart/index.php';
            return;
        }

        $total = 0;
        $cart = [];
        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
            $cart[$item['book_id']] = $item['quantity'];
        }

        $user = $this->userModel->getUserById($user_id);
        $email = $user['email'];
        $address = $user['address'] ?? 'Không có địa chỉ'; 

        $orderModel = new Order();
        $order_id = $orderModel->createOrder($user_id, $total, $cart, $address, $email);

        if ($order_id) {
            $bookModel->clearCart($user_id);
            $success = "Đặt hàng thành công! Mã đơn hàng: " . $order_id;
        } else {
            $error = "Đặt hàng thất bại.";
        }

        include 'views/checkout.php';
    }
}
?>