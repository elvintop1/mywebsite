<?php
require_once 'models/Book.php';

class BookController {
    private $bookModel;

    public function __construct() {
        $this->bookModel = new Book();
    }

    public function index() {
        $bestsellers = $this->bookModel->getBestsellers();
        $categories = $this->bookModel->getCategories();
        $booksByCategory = [];
        foreach ($categories as $category) {
            $booksByCategory[$category['id']] = [
                'category_name' => $category['name'],
                'books' => $this->bookModel->getBooksByCategoryForHomepage($category['id'], 4)
            ];
        }
        require_once 'views/books/index.php';
    }

    public function all() {
        $category_ids = isset($_GET['categories']) ? (array)$_GET['categories'] : [];
        $sort = isset($_GET['sort']) ? $_GET['sort'] : 'title_asc';
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 9;
        $books = $this->bookModel->getFilteredBooks($category_ids, $sort, $page, $limit);
        $totalBooks = $this->bookModel->getTotalFilteredBooks($category_ids);
        $totalPages = ceil($totalBooks / $limit);
        $categories = $this->bookModel->getCategories();
        require_once 'views/books/all.php';
    }

    public function show($id) {
        $book = $this->bookModel->getBookById($id);
        $comments = $this->bookModel->getComments($id);
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment']) && isset($_SESSION['user_id'])) {
            $comment = $_POST['comment'];
            $this->bookModel->addComment($id, $_SESSION['user_id'], $comment);
            header("Location: index.php?controller=book&action=show&id=$id");
        }
        require_once 'views/books/show.php';
    }

    public function addComment() {
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Bạn cần đăng nhập để bình luận']);
            exit();
        }
        $book_id = $_POST['book_id'];
        $comment = $_POST['comment'];
        $this->bookModel->addComment($book_id, $_SESSION['user_id'], $comment);
        $comments = $this->bookModel->getComments($book_id);
        echo json_encode($comments);
        exit();
    }

    public function search() {
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        if (empty($keyword)) {
            echo json_encode([]);
            exit();
        }
        $books = $this->bookModel->searchBooks($keyword);
        echo json_encode($books);
        exit();
    }

    public function searchResults() {
        $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 9;

        if (empty($keyword)) {
            $books = [];
            $totalBooks = 0;
        } else {
            $books = $this->bookModel->searchBooks($keyword, $limit, $page);
            $totalBooks = $this->bookModel->getTotalBooksByKeyword($keyword);
        }

        $totalPages = ceil($totalBooks / $limit);
        require_once 'views/books/search_results.php';
    }

    public function searchAll() {
        try {
            $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
            $category_ids = isset($_GET['categories']) && !empty($_GET['categories']) ? explode(',', $_GET['categories']) : [];
            $sort = isset($_GET['sort']) ? $_GET['sort'] : 'title_asc';
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = 9;

            $category_ids = array_filter($category_ids, function($id) {
                return is_numeric($id) && (int)$id > 0;
            });
            $category_ids = array_map('intval', $category_ids);

            $books = $this->bookModel->searchBooksWithFilters($keyword, $category_ids, $sort, $page, $limit);
            $totalBooks = $this->bookModel->getTotalBooksByKeywordAndFilters($keyword, $category_ids);
            $totalPages = ceil($totalBooks / $limit);

            echo json_encode([
                'books' => $books,
                'page' => $page,
                'totalPages' => $totalPages
            ]);
        } catch (Exception $e) {
            echo json_encode([
                'error' => 'Có lỗi xảy ra: ' . $e->getMessage()
            ]);
        }
        exit();
    }
}
?>