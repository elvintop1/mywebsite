<?php
require_once 'models/Book.php';

class CartController {
    private $bookModel;

    public function __construct() {
        $this->bookModel = new Book();
    }

    public function index() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        $user_id = $_SESSION['user_id'];
        // Debug: Ghi log user_id trong index
        error_log("Index - User ID: $user_id");

        $cartItems = $this->bookModel->getCartItems($user_id);
        // Debug: Ghi log cartItems trong index
        error_log("Index - Cart Items: " . print_r($cartItems, true));

        $total = 0;
        foreach ($cartItems as &$item) {
            $total += $item['price'] * $item['quantity'];
        }
        require 'views/cart/index.php';
    }

    public function add() {
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Bạn cần đăng nhập để thực hiện hành động này.']);
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $book_id = $_GET['id'];

        // Thêm sản phẩm vào giỏ hàng
        $result = $this->bookModel->addToCart($user_id, $book_id);
        if (!$result) {
            echo json_encode(['error' => 'Không thể thêm sản phẩm vào giỏ hàng.']);
            exit();
        }

        // Lấy danh sách sản phẩm trong giỏ hàng sau khi thêm
        $cartItems = $this->bookModel->getCartItems($user_id);

        // Tính tổng tiền
        $total = 0;
        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        // Debug: Ghi log hành động
        error_log("Added book_id $book_id to cart for user_id $user_id");

        echo json_encode([
            'success' => 'Sản phẩm đã được thêm vào giỏ hàng.',
            'cartItems' => $cartItems,
            'total' => $total
        ]);
        exit();
    }

    public function remove() {
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Bạn cần đăng nhập để thực hiện hành động này.']);
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $book_id = $_GET['id'];
        $this->bookModel->removeFromCart($user_id, $book_id);
        $cartEmpty = $this->bookModel->isCartEmpty($user_id);
        echo json_encode(['success' => 'Sản phẩm đã được xóa khỏi giỏ hàng.', 'cartEmpty' => $cartEmpty]);
    }

    public function increase() {
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Bạn cần đăng nhập để thực hiện hành động này.']);
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $book_id = $_GET['id'];
        $this->bookModel->updateCartQuantity($user_id, $book_id, 1);
        $quantity = $this->bookModel->getCartItemQuantity($user_id, $book_id);
        $book = $this->bookModel->getBookById($book_id);

        // Kiểm tra $book['price'] trước khi tính
        if (!isset($book['price']) || !is_numeric($book['price'])) {
            error_log("Invalid price for book_id $book_id: " . print_r($book['price'], true));
            echo json_encode(['error' => 'Giá sách không hợp lệ.']);
            exit();
        }

        // Ép kiểu $book['price'] thành số
        $price = (float) $book['price'];
        $subtotal = $price * $quantity; // Giá bằng VNĐ

        // Kiểm tra $subtotal
        if (is_nan($subtotal)) {
            error_log("NaN subtotal for book_id $book_id: Price: $price, Quantity: $quantity");
            echo json_encode(['error' => 'Không thể tính tổng giá trị.']);
            exit();
        }

        // Debug: Ghi log giá trị
        error_log("Book ID: $book_id, Price: $price, Quantity: $quantity, Subtotal: $subtotal");

        echo json_encode([
            'success' => 'Số lượng đã được tăng.',
            'quantity' => $quantity,
            'subtotal' => $subtotal // Trả về số, sẽ được định dạng ở client-side
        ]);
    }

    public function decrease() {
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Bạn cần đăng nhập để thực hiện hành động này.']);
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $book_id = $_GET['id'];
        $this->bookModel->updateCartQuantity($user_id, $book_id, -1);
        $quantity = $this->bookModel->getCartItemQuantity($user_id, $book_id);
        $cartEmpty = $this->bookModel->isCartEmpty($user_id);
        if ($cartEmpty) {
            echo json_encode(['success' => 'Sản phẩm đã được xóa khỏi giỏ hàng.', 'cartEmpty' => true]);
        } else {
            $book = $this->bookModel->getBookById($book_id);

            // Kiểm tra $book['price'] trước khi tính
            if (!isset($book['price']) || !is_numeric($book['price'])) {
                error_log("Invalid price for book_id $book_id: " . print_r($book['price'], true));
                echo json_encode(['error' => 'Giá sách không hợp lệ.']);
                exit();
            }

            // Ép kiểu $book['price'] thành số
            $price = (float) $book['price'];
            $subtotal = $price * $quantity; // Giá bằng VNĐ

            // Kiểm tra $subtotal
            if (is_nan($subtotal)) {
                error_log("NaN subtotal for book_id $book_id: Price: $price, Quantity: $quantity");
                echo json_encode(['error' => 'Không thể tính tổng giá trị.']);
                exit();
            }

            // Debug: Ghi log giá trị
            error_log("Book ID: $book_id, Price: $price, Quantity: $quantity, Subtotal: $subtotal");

            echo json_encode([
                'success' => 'Số lượng đã được giảm.',
                'quantity' => $quantity,
                'subtotal' => $subtotal // Trả về số, sẽ được định dạng ở client-side
            ]);
        }
    }

    public function getCartItemCount() {
        if (!isset($_SESSION['user_id'])) {
            error_log("User not logged in, returning cart item count: 0");
            echo json_encode(['count' => 0]);
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $cartItems = $this->bookModel->getCartItems($user_id);
        $count = 0;
        foreach ($cartItems as $item) {
            $count += $item['quantity'];
        }

        error_log("Cart Item Count for user_id $user_id: $count, Cart Items: " . print_r($cartItems, true));

        echo json_encode(['count' => $count]);
        exit();
    }

    public function checkCart() {
        if (!isset($_SESSION['user_id'])) {
            echo json_encode(['error' => 'Bạn cần đăng nhập để thực hiện hành động này.']);
            exit();
        }

        $user_id = $_SESSION['user_id'];
        $cartItems = $this->bookModel->getCartItems($user_id);
        echo json_encode(['isEmpty' => empty($cartItems)]);
        exit();
    }

    public function checkout() {
        // Kiểm tra đăng nhập
        if (!isset($_SESSION['user_id'])) {
            header('Location: index.php?controller=user&action=login');
            exit();
        }

        $user_id = $_SESSION['user_id'];
        // Debug: Ghi log user_id trong checkout
        error_log("Checkout - User ID: $user_id");

        $cartItems = $this->bookModel->getCartItems($user_id);
        // Debug: Ghi log cartItems trong checkout
        error_log("Checkout - Cart Items: " . print_r($cartItems, true));

        error_log("Checkout - Cart Items Count: " . count($cartItems));

        // Kiểm tra giỏ hàng trống
        if (empty($cartItems)) {
            $_SESSION['error'] = 'Giỏ hàng của bạn đang trống. Vui lòng thêm sách trước khi thanh toán.';
            header('Location: index.php?controller=cart&action=index');
            exit();
        }

        // Chuyển hướng sang trang user để xử lý thanh toán
        header('Location: index.php?controller=user&action=profile');
        exit();
    }
}