<?php
session_start();
require_once 'controllers/BookController.php';
require_once 'controllers/CartController.php';
require_once 'controllers/UserController.php';
require_once 'controllers/ContactController.php';
require_once 'controllers/OrderController.php'; // Thêm OrderController

$controller = isset($_GET['controller']) ? $_GET['controller'] : 'book';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';
$id = isset($_GET['id']) ? $_GET['id'] : null;
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : null;

switch ($controller) {
    case 'book':
        $bookController = new BookController();
        if ($action == 'index') $bookController->index();
        elseif ($action == 'all') $bookController->all();
        elseif ($action == 'show' && $id) $bookController->show($id);
        elseif ($action == 'addComment') $bookController->addComment();
        elseif ($action == 'search') $bookController->search();
        elseif ($action == 'searchResults') $bookController->searchResults();
        elseif ($action == 'searchAll') $bookController->searchAll();
        break;
    case 'cart':
        $cartController = new CartController();
        if ($action == 'index') $cartController->index();
        elseif ($action == 'add' && $id) $cartController->add($id);
        elseif ($action == 'remove' && $id) $cartController->remove($id);
        elseif ($action == 'increase' && $id) $cartController->increase($id);
        elseif ($action == 'decrease' && $id) $cartController->decrease($id);
        elseif ($action == 'getCartItemCount') $cartController->getCartItemCount();
        break;
    case 'user':
        $userController = new UserController();
        if ($action == 'register') $userController->register();
        elseif ($action == 'login') $userController->login();
        elseif ($action == 'profile') $userController->profile();
        elseif ($action == 'updateProfile') $userController->updateProfile(); // Thêm xử lý cho updateProfile
        elseif ($action == 'dashboard') $userController->dashboard();
        elseif ($action == 'manageUsers') $userController->manageUsers();
        elseif ($action == 'addUser') $userController->addUser();
        elseif ($action == 'editUser' && $id) $userController->editUser($id);
        elseif ($action == 'deleteUser' && $id) $userController->deleteUser($id);
        elseif ($action == 'addBook') $userController->addBook();
        elseif ($action == 'editBook' && $id) $userController->editBook($id);
        elseif ($action == 'deleteBook' && $id) $userController->deleteBook($id);
        elseif ($action == 'manageCategories') $userController->manageCategories();
        elseif ($action == 'addCategory') $userController->addCategory();
        elseif ($action == 'editCategory' && $id) $userController->editCategory($id);
        elseif ($action == 'deleteCategory' && $id) $userController->deleteCategory($id);
        elseif ($action == 'logout') $userController->logout();
        elseif ($action == 'checkout') $userController->checkout();
        elseif ($action == 'orderDetails' && $order_id) $userController->orderDetails($order_id);
        elseif ($action == 'getOrderDetails') $userController->getOrderDetails();
        break;
    case 'contact':
        $contactController = new ContactController();
        if ($action == 'index') $contactController->index();
        elseif ($action == 'manage') $contactController->manage();
        break;
    case 'order':
        $orderController = new OrderController();
        if ($action == 'manage') $orderController->manage();
        elseif ($action == 'detail' && $id) $orderController->detail();
        elseif ($action == 'updateStatus' && $id) $orderController->updateStatus();
        break;
    default:
        echo "Trang không tồn tại!";
}
?>