<?php include 'views/layouts/header.php'; ?>

<h1>Quản lý sách</h1>
<a href="index.php?controller=user&action=addBook" class="btn btn-success mb-3">Thêm sách mới</a>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sách</th>
            <th>Tác giả</th>
            <th>Giá</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($books as $book) { ?>
            <tr>
                <td><?php echo $book['id']; ?></td>
                <td><?php echo $book['title']; ?></td>
                <td><?php echo $book['author']; ?></td>
                <td><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</td>
                <td>
                    <a href="index.php?controller=user&action=editBook&id=<?php echo $book['id']; ?>" class="btn btn-warning btn-sm">Sửa</a>
                    <button class="btn btn-danger btn-sm delete-book" data-id="<?php echo $book['id']; ?>">Xóa</button>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<?php include 'views/layouts/footer.php'; ?>