</div>
    <footer class="pt-5 pb-3 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="fw-bold mb-3">Sản phẩm</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-decoration-none">Sách giáo khoa</a></li>
                        <li><a href="#" class="text-decoration-none">Tiểu thuyết</a></li>
                        <li><a href="#" class="text-decoration-none">Văn học</a></li>
                        <li><a href="#" class="text-decoration-none">Truyện tranh</a></li>
                        <li><a href="#" class="text-decoration-none">Phát triển bản thân</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="fw-bold mb-3">Thông tin</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-decoration-none">Câu hỏi thường gặp</a></li>
                        <li><a href="#" class="text-decoration-none">Blog</a></li>
                        <li><a href="#" class="text-decoration-none">Hỗ trợ</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="fw-bold mb-3">Công ty</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-decoration-none">Về chúng tôi</a></li>
                        <li><a href="#" class="text-decoration-none">Tuyển dụng</a></li>
                        <li><a href="#" class="text-decoration-none">Liên hệ</a></li>
                        <li><a href="#" class="text-decoration-none">BookStore Media</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="fw-bold mb-3">Đăng ký nhận tin</h5>
                    <form>
                        <div class="input-group mb-3">
                            <input type="email" class="form-control rounded-start" placeholder="Email address" aria-label="Email address">
                            <button class="btn btn-primary rounded-end" type="submit"><i class="bi bi-arrow-right"></i></button>
                        </div>
                    </form>
                    <p class="small">Hãy để chúng tôi gửi tin tức mới nhất về sách và các ưu đãi đặc biệt đến bạn!</p>
                </div>
            </div>
            <div class="row align-items-center mt-4 pt-4 border-top">
                <div class="col-md-3 mb-3 mb-md-0">
                    <a href="index.php" class="d-block">
                        <h4><i class="bi bi-book-fill me-2"></i>BookStore</h4>
                    </a>
                </div>
                <div class="col-md-6 text-center mb-3 mb-md-0">
                    <a href="#" class="text-decoration-none me-3">Terms</a>
                    <a href="#" class="text-decoration-none me-3">Privacy</a>
                    <a href="#" class="text-decoration-none">Cookies</a>
                </div>
                <div class="col-md-3 text-md-end">
                    <a href="#" class="me-3"><i class="bi bi-linkedin"></i></a>
                    <a href="#" class="me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="me-3"><i class="bi bi-twitter"></i></a>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>