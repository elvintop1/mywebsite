<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- Defer scripts to improve performance -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js" defer></script>
</head>
<body>
    <?php
    // Khởi tạo số lượng item trong giỏ hàng
    $cartItemCount = 0;
    if (isset($_SESSION['user_id'])) {
        $bookModel = new Book();
        $cartItems = $bookModel->getCartItems($_SESSION['user_id']);
        $cartItemCount = count($cartItems);
    }
    ?>
    <nav class="navbar navbar-expand-lg navbar-gradient shadow-lg">
        <div class="container">
            <a class="navbar-brand flex items-center space-x-2 hover:scale-105 transition-transform duration-300" href="index.php">
                <i class="bi bi-book-fill text-2xl text-blue-600 animate__animated animate__pulse animate__infinite"></i>
                <span class="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-500">BookStore</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <form class="d-flex me-auto" role="search" id="search-form">
                    <div class="input-group relative">
                        <input class="form-control search-input transition-all duration-300 focus:w-96" type="search" placeholder="Tìm kiếm sách..." aria-label="Search" id="search-input" autocomplete="off">
                        <span class="input-group-text bg-white border-0"><i class="bi bi-search text-blue-600"></i></span>
                        <div class="search-suggestions" id="search-results">
                            <ul id="search-results-list"></ul>
                        </div>
                    </div>
                </form>
                <ul class="navbar-nav ms-auto space-x-2">
                    <?php if (isset($_SESSION['role']) && ($_SESSION['role'] == 'super_admin' || $_SESSION['role'] == 'admin')) { ?>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=dashboard"><i class="bi bi-gear-fill me-1"></i> Quản lý sách</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=manageCategories"><i class="bi bi-tags-fill me-1"></i> Quản lý thể loại</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=contact&action=manage"><i class="bi bi-envelope-fill me-1"></i> Quản lý liên hệ</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=manageUsers"><i class="bi bi-person-fill me-1"></i> Quản lý tài khoản</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=order&action=manage"><i class="bi bi-cart-fill me-1"></i> Quản lý đơn hàng</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=addBook"><i class="bi bi-plus-circle me-1"></i> Thêm sách</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=logout"><i class="bi bi-box-arrow-right me-1"></i> Đăng xuất</a></li>
                    <?php } elseif (isset($_SESSION['role']) && $_SESSION['role'] == 'user') { ?>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php"><i class="bi bi-house-door-fill me-1"></i> Trang chủ</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=book&action=all"><i class="bi bi-bookshelf me-1"></i> Tất cả sách</a></li>
                        <li class="nav-item">
                            <a class="nav-link nav-link-hover" href="index.php?controller=cart&action=index">
                                <i class="bi bi-cart-fill me-1"></i> Giỏ hàng
                                <?php if ($cartItemCount > 0) { ?>
                                    <span class="badge bg-red-500 text-white rounded-full px-2 py-1 text-xs"><?php echo $cartItemCount; ?></span>
                                <?php } ?>
                            </a>
                        </li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=profile"><i class="bi bi-person-fill me-1"></i> Hồ sơ</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=contact&action=index"><i class="bi bi-telephone-fill me-1"></i> Liên hệ</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=logout"><i class="bi bi-box-arrow-right me-1"></i> Đăng xuất</a></li>
                    <?php } else { ?>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php"><i class="bi bi-house-door-fill me-1"></i> Trang chủ</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=book&action=all"><i class="bi bi-bookshelf me-1"></i> Tất cả sách</a></li>
                        <li class="nav-item">
                            <a class="nav-link nav-link-hover" href="index.php?controller=cart&action=index">
                                <i class="bi bi-cart-fill me-1"></i> Giỏ hàng
                                <?php if ($cartItemCount > 0) { ?>
                                    <span class="badge bg-red-500 text-white rounded-full px-2 py-1 text-xs"><?php echo $cartItemCount; ?></span>
                                <?php } ?>
                            </a>
                        </li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=contact&action=index"><i class="bi bi-telephone-fill me-1"></i> Liên hệ</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=login"><i class="bi bi-box-arrow-in-right me-1"></i> Đăng nhập</a></li>
                        <li class="nav-item"><a class="nav-link nav-link-hover" href="index.php?controller=user&action=register"><i class="bi bi-person-plus-fill me-1"></i> Đăng ký</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
    <script>
        // JavaScript để xử lý ẩn/hiện navbar khi cuộn
        let lastScrollTop = 0;
        const navbar = document.querySelector('.navbar');

        window.addEventListener('scroll', function() {
            let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollTop > lastScrollTop) {
                // Cuộn xuống: ẩn navbar
                navbar.classList.add('hide-nav');
            } else {
                // Cuộn lên: hiện navbar
                navbar.classList.remove('hide-nav');
            }
            lastScrollTop = scrollTop <= 0 ? 0 : scrollTop; // Tránh giá trị âm
        });
    </script>