<?php include 'views/layouts/header.php'; ?>
<h1>Thanh toán</h1>
<p>Cảm ơn bạn đã mua sách! Đơn hàng của bạn đã được ghi nhận.</p>
<?php include 'views/layouts/footer.php'; ?>