<?php include 'views/layouts/header.php'; ?>

<div class="container mt-5">
    <h2 class="text-2xl font-bold mb-4 text-gray-800">Đăng Ký</h2>

    <?php if (isset($success)) { ?>
        <div id="success-message" class="alert alert-success fade show"><?php echo $success; ?></div>
    <?php } elseif (isset($error)) { ?>
        <div id="error-message" class="alert alert-danger fade show"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST">
        <div class="mb-3">
            <label for="username" class="form-label">Tên đăng nhập</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Mật khẩu</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="full_name" class="form-label">Họ và Tên</label>
            <input type="text" class="form-control" id="full_name" name="full_name" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Số Điện Thoại</label>
            <input type="text" class="form-control" id="phone" name="phone" placeholder="Ví dụ: +84123456789">
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Địa Chỉ</label>
            <input type="text" class="form-control" id="address" name="address">
        </div>
        <button type="submit" class="btn btn-primary">Đăng Ký</button>
    </form>
</div>

<script>
// Tự động ẩn thông báo với hiệu ứng mờ dần sau 2 giây
document.addEventListener('DOMContentLoaded', function () {
    const successMessage = document.getElementById('success-message');
    const errorMessage = document.getElementById('error-message');

    if (successMessage) {
        setTimeout(() => {
            successMessage.classList.remove('show');
            successMessage.classList.add('fade');
        }, 2000); 
    }

    if (errorMessage) {
        setTimeout(() => {
            errorMessage.classList.remove('show');
            errorMessage.classList.add('fade');
        }, 2000); 
    }
});
</script>

<?php include 'views/layouts/footer.php'; ?>