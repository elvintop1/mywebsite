<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Chi tiết đơn hàng</h1>

<!-- Thông tin đơn hàng -->
<div class="mb-4">
    <p><strong>STT:</strong> <?php echo htmlspecialchars($orderNumber); ?></p>
    <p><strong>Tổng tiền:</strong> <span class="text-danger"><?php echo number_format($order['total'], 0, ',', '.'); ?> VNĐ</span></p>
    <p><strong>Ngày đặt:</strong> <?php echo $order['created_at']; ?></p>
</div>

<!-- Danh sách sách đã mua -->
<h3>Danh sách sách đã mua</h3>
<?php if (empty($orderDetails)) { ?>
    <p>Không có sách nào trong đơn hàng này.</p>
<?php } else { ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Ảnh</th>
                <th>Tên sách</th>
                <th>Số lượng</th>
                <th>Giá</th>
                <th>Tổng</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orderDetails as $item) { ?>
                <tr>
                    <td><img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" style="width: 50px; height: auto;"></td>
                    <td><?php echo htmlspecialchars($item['title']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td class="text-danger"><?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</td>
                    <td class="text-danger"><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?> VNĐ</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
<?php } ?>

<a href="index.php?controller=user&action=profile" class="btn btn-primary mt-3"><i class="bi bi-arrow-left me-1"></i> Quay lại</a>

<?php include 'views/layouts/footer.php'; ?>