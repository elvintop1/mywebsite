<?php include 'views/layouts/header.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-4">
        <h1 class="text-center mb-4">Đăng nhập</h1>
        <form method="POST" id="loginForm" class="p-4 bg-white rounded shadow-sm">
            <div class="mb-3">
                <label for="username" class="form-label">Tên đăng nhập</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Mật khẩu</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
            <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
            <p class="mt-3 text-center">Chưa có tài khoản? <a href="index.php?controller=user&action=register">Đăng ký</a></p>
        </form>
    </div>
</div>
<?php include 'views/layouts/footer.php'; ?>