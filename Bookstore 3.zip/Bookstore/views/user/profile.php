<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Hồ sơ người dùng</h1>

<?php if (isset($_SESSION['success'])) { ?>
    <div id="success-message" class="alert alert-success fade show"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php } ?>
<?php if (isset($_SESSION['error'])) { ?>
    <div id="error-message" class="alert alert-danger fade show"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php } ?>

<h3>Thông tin cá nhân</h3>
<div class="card mb-4">
    <div class="card-body">
        <form method="POST" action="index.php?controller=user&action=updateProfile">
            <div class="mb-3">
                <label for="username" class="form-label"><i class="bi bi-person-circle me-2 text-primary"></i> <strong>Tên đăng nhập:</strong></label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($_SESSION['username']); ?>" readonly>
                <small class="text-muted">Tên đăng nhập không thể thay đổi.</small>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"><i class="bi bi-envelope-fill me-2 text-primary"></i> <strong>Email:</strong></label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="full_name" class="form-label"><i class="bi bi-person-lines-fill me-2 text-primary"></i> <strong>Họ và Tên:</strong></label>
                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($_SESSION['full_name']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Cập nhật thông tin</button>
        </form>
    </div>
</div>

<h3>Lịch sử đơn hàng</h3>
<?php if (empty($orders)) { ?>
    <p>Chưa có đơn hàng nào.</p>
<?php } else { ?>
    <table class="table">
        <thead>
            <tr>
                <th>STT</th>
                <th>Tổng tiền</th>
                <th>Ngày đặt</th>
                <th>Chi tiết</th>
            </tr>
        </thead>
        <tbody>
            <?php $orderNumber = 1; ?>
            <?php foreach ($orders as $order) { ?>
                <tr>
                    <td><?php echo $orderNumber; ?></td>
                    <td class="text-danger"><?php echo number_format($order['total'], 0, ',', '.'); ?> VNĐ</td>
                    <td><?php echo $order['created_at']; ?></td>
                    <td>
                        <a href="index.php?controller=user&action=orderDetails&order_id=<?php echo $order['id']; ?>&order_number=<?php echo $orderNumber; ?>" class="btn btn-info">
                            <i class="bi bi-eye-fill me-1"></i> Xem chi tiết
                        </a>
                    </td>
                </tr>
                <?php $orderNumber++; // Tăng số thứ tự ?>
            <?php } ?>
        </tbody>
    </table>
<?php } ?>
<a href="index.php?controller=user&action=logout" class="btn btn-danger mt-3"><i class="bi bi-box-arrow-right me-1"></i> Đăng xuất</a>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const successMessage = document.getElementById('success-message');
    const errorMessage = document.getElementById('error-message');

    if (successMessage) {
        setTimeout(() => {
            successMessage.classList.remove('show');
            successMessage.classList.add('fade');
        }, 2000); 
    }

    if (errorMessage) {
        setTimeout(() => {
            errorMessage.classList.remove('show');
            errorMessage.classList.add('fade');
        }, 2000); 
    }
});
</script>

<?php include 'views/layouts/footer.php'; ?>