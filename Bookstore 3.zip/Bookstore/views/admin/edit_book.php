<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Sửa sách</h1>
<form method="POST" enctype="multipart/form-data" id="editBookForm" class="p-4 bg-white rounded shadow-sm">
    <div class="mb-3">
        <label for="title" class="form-label">Tên sách</label>
        <input type="text" class="form-control" id="title" name="title" value="<?php echo $book['title']; ?>" required>
    </div>
    <div class="mb-3">
        <label for="author" class="form-label">Tác giả</label>
        <input type="text" class="form-control" id="author" name="author" value="<?php echo $book['author']; ?>" required>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Giá (VNĐ)</label>
        <input type="number" class="form-control" id="price" name="price" value="<?php echo $book['price']; ?>" required>
    </div>
    <div class="mb-3">
        <label for="category_id" class="form-label">Thể loại</label>
        <select class="form-select" id="category_id" name="category_id" required>
            <?php foreach ($categories as $category) { ?>
                <option value="<?php echo $category['id']; ?>" <?php echo $book['category_id'] == $category['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($category['name']); ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Hình ảnh (để trống nếu không thay đổi)</label>
        <input type="file" class="form-control" id="image" name="image">
        <img src="<?php echo $book['image']; ?>" alt="<?php echo $book['title']; ?>" width="100" class="mt-2">
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Mô tả</label>
        <textarea class="form-control" id="description" name="description" rows="3" required><?php echo $book['description']; ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save-fill me-1"></i> Cập nhật</button>
</form>

<?php include 'views/layouts/footer.php'; ?>