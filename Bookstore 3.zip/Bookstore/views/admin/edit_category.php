<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Sửa thể loại</h1>
<form method="POST" class="p-4 bg-white rounded shadow-sm">
    <div class="mb-3">
        <label for="name" class="form-label">Tên thể loại</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save-fill me-1"></i> Cập nhật</button>
</form>

<?php include 'views/layouts/footer.php'; ?>