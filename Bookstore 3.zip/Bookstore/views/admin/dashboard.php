<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4"><?php echo $_SESSION['role'] == 'super_admin' ? 'Super Admin Dashboard' : 'Admin Dashboard'; ?></h1>

<!-- Form tìm kiếm -->
<div class="mb-4">
    <form method="GET" action="index.php" class="d-flex">
        <input type="hidden" name="controller" value="user">
        <input type="hidden" name="action" value="dashboard">
        <div class="input-group">
            <input type="text" class="form-control" name="keyword" placeholder="Tìm kiếm sách..." value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>">
            <button type="submit" class="btn btn-primary"><i class="bi bi-search me-1"></i> Tìm kiếm</button>
            <?php if (isset($_GET['keyword']) && !empty($_GET['keyword'])) { ?>
                <a href="index.php?controller=user&action=dashboard" class="btn btn-secondary ms-2"><i class="bi bi-x-circle me-1"></i> Xóa bộ lọc</a>
            <?php } ?>
        </div>
    </form>
</div>

<a href="index.php?controller=user&action=addBook" class="btn btn-success mb-3"><i class="bi bi-plus-circle me-1"></i> Thêm sách mới</a>

<table class="table table-striped" id="books-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sách</th>
            <th>Tác giả</th>
            <th>Giá</th>
            <th>Thể loại</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($books)) { ?>
            <tr>
                <td colspan="6" class="text-center">Không tìm thấy sách nào.</td>
            </tr>
        <?php } else { ?>
            <?php foreach ($books as $book) { ?>
                <tr data-id="<?php echo $book['id']; ?>">
                    <td><?php echo $book['id']; ?></td>
                    <td><?php echo $book['title']; ?></td>
                    <td><?php echo $book['author']; ?></td>
                    <td><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</td>
                    <td><?php echo $book['category_name']; ?></td>
                    <td>
                        <a href="index.php?controller=user&action=editBook&id=<?php echo $book['id']; ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill me-1"></i> Sửa</a>
                        <button class="btn btn-danger btn-sm delete-book" data-id="<?php echo $book['id']; ?>"><i class="bi bi-trash-fill me-1"></i> Xóa</button>
                    </td>
                </tr>
            <?php } ?>
        <?php } ?>
    </tbody>
</table>

<!-- Phân trang -->
<?php if (!empty($books)) { ?>
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <!-- Nút Previous -->
            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="index.php?controller=user&action=dashboard&page=<?php echo $page - 1; ?><?php echo isset($_GET['keyword']) ? '&keyword=' . urlencode($_GET['keyword']) : ''; ?>" aria-label="Previous">
                    <span aria-hidden="true">«</span>
                </a>
            </li>

            <!-- Trang đầu -->
            <li class="page-item <?php echo $page == 1 ? 'active' : ''; ?>">
                <a class="page-link" href="index.php?controller=user&action=dashboard&page=1<?php echo isset($_GET['keyword']) ? '&keyword=' . urlencode($_GET['keyword']) : ''; ?>">1</a>
            </li>

            <?php
            if ($page > 3) {
                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }

            $start = max(2, $page - 1);
            $end = min($totalPages - 1, $page + 1);
            for ($i = $start; $i <= $end; $i++) {
                echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
                echo '<a class="page-link" href="index.php?controller=user&action=dashboard&page=' . $i . (isset($_GET['keyword']) ? '&keyword=' . urlencode($_GET['keyword']) : '') . '">' . $i . '</a>';
                echo '</li>';
            }

            if ($page < $totalPages - 2) {
                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }

            if ($totalPages > 1) {
                echo '<li class="page-item ' . ($page == $totalPages ? 'active' : '') . '">';
                echo '<a class="page-link" href="index.php?controller=user&action=dashboard&page=' . $totalPages . (isset($_GET['keyword']) ? '&keyword=' . urlencode($_GET['keyword']) : '') . '">' . $totalPages . '</a>';
                echo '</li>';
            }
            ?>

            <!-- Nút Next -->
            <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                <a class="page-link" href="index.php?controller=user&action=dashboard&page=<?php echo $page + 1; ?><?php echo isset($_GET['keyword']) ? '&keyword=' . urlencode($_GET['keyword']) : ''; ?>" aria-label="Next">
                    <span aria-hidden="true">»</span>
                </a>
            </li>
        </ul>
    </nav>
<?php } ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gắn sự kiện click cho tất cả các nút delete-book
    document.querySelectorAll('.delete-book').forEach(button => {
        button.addEventListener('click', function() {
            const bookId = this.getAttribute('data-id');

            // Hiển thị hộp thoại xác nhận
            Swal.fire({
                title: 'Bạn có chắc chắn?',
                text: "Bạn có muốn xóa sách này không?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Có, xóa!',
                cancelButtonText: 'Hủy'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Gửi yêu cầu AJAX để xóa sách
                    fetch(`index.php?controller=user&action=deleteBook&id=${bookId}`, {
                        method: 'GET'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Xóa dòng khỏi bảng
                            document.querySelector(`tr[data-id="${bookId}"]`).remove();
                            Swal.fire(
                                'Đã xóa!',
                                data.success,
                                'success'
                            );
                        } else {
                            Swal.fire(
                                'Lỗi!',
                                data.error || 'Không thể xóa sách.',
                                'error'
                            );
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire(
                            'Lỗi!',
                            'Đã xảy ra lỗi khi xóa sách.',
                            'error'
                        );
                    });
                }
            });
        });
    });
});
</script>

<?php include 'views/layouts/footer.php'; ?>