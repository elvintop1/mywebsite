<?php include 'views/layouts/header.php'; ?>
<h1 class="text-center">Đăng nhập Admin</h1>
<div class="row justify-content-center">
    <div class="col-md-4">
        <form method="POST" id="loginForm">
            <div class="mb-3">
                <label for="username" class="form-label">Tên đăng nhập</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Mật khẩu</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
            <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
        </form>
    </div>
</div>
<?php include 'views/layouts/footer.php'; ?>