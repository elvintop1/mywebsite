<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Thêm thể loại mới</h1>
<form method="POST" class="p-4 bg-white rounded shadow-sm">
    <div class="mb-3">
        <label for="name" class="form-label">Tên thể loại</label>
        <input type="text" class="form-control" id="name" name="name" required>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i> Thêm thể loại</button>
</form>

<?php include 'views/layouts/footer.php'; ?>