<?php include 'views/layouts/header.php'; ?>

<div class="container mt-5">
    <h2 class="text-2xl font-bold mb-4 text-gray-800">Chi Tiết Đơn Hàng #<?php echo htmlspecialchars($order['id']); ?></h2>

    <?php if (isset($success)) { ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php } elseif (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <div class="card mb-4">
        <div class="card-header bg-gray-200">
            <h5 class="mb-0">Thông Tin Đơn Hàng</h5>
        </div>
        <div class="card-body">
            <p><strong>ID Đơn Hàng:</strong> <?php echo htmlspecialchars($order['id']); ?></p>
            <p><strong>Tên Khách Hàng:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
            <p><strong>Địa Chỉ:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
            <p><strong>Tổng Tiền:</strong> <?php echo number_format($order['total'], 0, ',', '.'); ?> VNĐ</p>
            <p><strong>Trạng Thái:</strong> 
                <form method="POST" action="index.php?controller=order&action=updateStatus&id=<?php echo $order['id']; ?>" class="d-inline">
                    <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()">
                        <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Đang xử lý</option>
                        <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Đã giao hàng</option>
                        <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Đã hủy</option>
                    </select>
                </form>
            </p>
            <p><strong>Ngày Đặt Hàng:</strong> <?php echo htmlspecialchars($order['created_at']); ?></p>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-gray-200">
            <h5 class="mb-0">Sản Phẩm Trong Đơn Hàng</h5>
        </div>
        <div class="card-body">
            <?php if (empty($orderItems)) { ?>
                <p class="text-gray-600">Không có sản phẩm nào trong đơn hàng.</p>
            <?php } else { ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Hình Ảnh</th>
                                <th>Tên Sách</th>
                                <th>Số Lượng</th>
                                <th>Giá</th>
                                <th>Thành Tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orderItems as $item) { ?>
                                <tr>
                                    <td><img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" class="img-thumbnail" style="width: 50px; height: 50px;"></td>
                                    <td><?php echo htmlspecialchars($item['title']); ?></td>
                                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                    <td><?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</td>
                                    <td><?php echo number_format($item['quantity'] * $item['price'], 0, ',', '.'); ?> VNĐ</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php } ?>
        </div>
    </div>

    <div class="mt-4">
        <a href="index.php?controller=order&action=manage" class="btn btn-secondary"><i class="bi bi-arrow-left me-1"></i> Quay Lại</a>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>