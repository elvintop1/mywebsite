<?php include 'views/layouts/header.php'; ?>

<div class="container mt-5">
    <h2 class="text-2xl font-bold mb-4 text-gray-800">Quản Lý Đơn Hàng</h2>

    <?php if (isset($success)) { ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php } elseif (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <?php if (empty($orders)) { ?>
        <p class="text-gray-600">Không có đơn hàng nào.</p>
    <?php } else { ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="bg-gray-200">
                    <tr>
                        <th>ID</th>
                        <th>Tên Khách Hàng</th>
                        <th>Tổng Tiền</th>
                        <th>Trạng Thái</th>
                        <th>Ngày Đặt Hàng</th>
                        <th>Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                            <td><?php echo number_format($order['total'], 0, ',', '.'); ?> VNĐ</td>
                            <td>
                                <form method="POST" action="index.php?controller=order&action=updateStatus&id=<?php echo $order['id']; ?>" class="d-inline">
                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                        <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Đang xử lý</option>
                                        <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Đã giao hàng</option>
                                        <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Đã hủy</option>
                                    </select>
                                </form>
                            </td>
                            <td><?php echo htmlspecialchars($order['created_at']); ?></td>
                            <td>
                                <a href="index.php?controller=order&action=detail&id=<?php echo $order['id']; ?>" class="btn btn-primary btn-sm"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php } ?>
</div>

<?php include 'views/layouts/footer.php'; ?>