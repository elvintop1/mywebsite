<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Xóa thể loại</h1>
<p>Bạn có chắc chắn muốn xóa thể loại "<strong><?php echo htmlspecialchars($category['name']); ?></strong>" không? (Lưu ý: Các sách thuộc thể loại này sẽ không hiển thị đúng nếu không được gán lại thể loại khác.)</p>
<form method="POST">
    <button type="submit" class="btn btn-danger"><i class="bi bi-trash-fill me-1"></i> Xóa</button>
    <a href="index.php?controller=user&action=manageCategories" class="btn btn-secondary"><i class="bi bi-x-circle me-1"></i> Hủy</a>
</form>

<?php include 'views/layouts/footer.php'; ?>