<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Quản lý tài khoản</h1>
<a href="index.php?controller=user&action=addUser" class="btn btn-success mb-3"><i class="bi bi-plus-circle me-1"></i> Thêm tài khoản mới</a>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên đăng nhập</th>
            <th>Email</th>
            <th>Họ và tên</th>
            <th>Vai trò</th>
            <th>Ngày tạo</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user) { ?>
            <tr data-user-id="<?php echo $user['id']; ?>">
                <td><?php echo $user['id']; ?></td>
                <td><?php echo htmlspecialchars($user['username']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['role']); ?></td>
                <td><?php echo $user['created_at']; ?></td>
                <td>
                    <a href="index.php?controller=user&action=editUser&id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill me-1"></i> Sửa</a>
                    <button class="btn btn-danger btn-sm delete-user" data-id="<?php echo $user['id']; ?>"><i class="bi bi-trash-fill me-1"></i> Xóa</button>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<!-- Phân trang -->
<nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
        <!-- Nút Previous -->
        <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
            <a class="page-link" href="index.php?controller=user&action=manageUsers&page=<?php echo $page - 1; ?>" aria-label="Previous">
                <span aria-hidden="true">«</span>
            </a>
        </li>

        <!-- Trang đầu -->
        <li class="page-item <?php echo $page == 1 ? 'active' : ''; ?>">
            <a class="page-link" href="index.php?controller=user&action=manageUsers&page=1">1</a>
        </li>

        <?php
        if ($page > 3) {
            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        $start = max(2, $page - 1);
        $end = min($totalPages - 1, $page + 1);
        for ($i = $start; $i <= $end; $i++) {
            echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
            echo '<a class="page-link" href="index.php?controller=user&action=manageUsers&page=' . $i . '">' . $i . '</a>';
            echo '</li>';
        }

        if ($page < $totalPages - 2) {
            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        if ($totalPages > 1) {
            echo '<li class="page-item ' . ($page == $totalPages ? 'active' : '') . '">';
            echo '<a class="page-link" href="index.php?controller=user&action=manageUsers&page=' . $totalPages . '">' . $totalPages . '</a>';
            echo '</li>';
        }
        ?>

        <!-- Nút Next -->
        <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
            <a class="page-link" href="index.php?controller=user&action=manageUsers&page=<?php echo $page + 1; ?>" aria-label="Next">
                <span aria-hidden="true">»</span>
            </a>
        </li>
    </ul>
</nav>

<?php include 'views/layouts/footer.php'; ?>