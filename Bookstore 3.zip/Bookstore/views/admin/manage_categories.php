<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Quản lý thể loại</h1>
<a href="index.php?controller=user&action=addCategory" class="btn btn-success mb-3"><i class="bi bi-plus-circle me-1"></i> Thêm thể loại mới</a>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên thể loại</th>
            <th>Ngày tạo</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($categories as $category) { ?>
            <tr>
                <td><?php echo $category['id']; ?></td>
                <td><?php echo htmlspecialchars($category['name']); ?></td>
                <td><?php echo $category['created_at']; ?></td>
                <td>
                    <a href="index.php?controller=user&action=editCategory&id=<?php echo $category['id']; ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill me-1"></i> Sửa</a>
                    <a href="index.php?controller=user&action=deleteCategory&id=<?php echo $category['id']; ?>" class="btn btn-danger btn-sm"><i class="bi bi-trash-fill me-1"></i> Xóa</a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<?php include 'views/layouts/footer.php'; ?>