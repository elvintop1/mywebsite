<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Thêm sách mới</h1>
<form method="POST" enctype="multipart/form-data" id="addBookForm" class="p-4 bg-white rounded shadow-sm">
    <div class="mb-3">
        <label for="title" class="form-label">Tên sách</label>
        <input type="text" class="form-control" id="title" name="title" required>
    </div>
    <div class="mb-3">
        <label for="author" class="form-label">Tác giả</label>
        <input type="text" class="form-control" id="author" name="author" required>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Giá (VNĐ)</label>
        <input type="number" class="form-control" id="price" name="price" required>
    </div>
    <div class="mb-3">
        <label for="category_id" class="form-label">Thể loại</label>
        <select class="form-select" id="category_id" name="category_id" required>
            <?php foreach ($categories as $category) { ?>
                <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Hình ảnh</label>
        <input type="file" class="form-control" id="image" name="image" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Mô tả</label>
        <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i> Thêm sách</button>
</form>

<?php include 'views/layouts/footer.php'; ?>