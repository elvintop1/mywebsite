<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Thêm tài khoản mới</h1>

<!-- Hiển thị thông báo lỗi nếu có -->
<?php if (isset($_SESSION['error'])) { ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php } ?>

<form method="POST" class="p-4 bg-white rounded shadow-sm">
    <div class="mb-3">
        <label for="username" class="form-label">Tên đăng nhập</label>
        <input type="text" class="form-control" id="username" name="username" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Mật khẩu</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
    </div>
    <div class="mb-3">
        <label for="full_name" class="form-label">Họ và tên</label>
        <input type="text" class="form-control" id="full_name" name="full_name" required>
    </div>
    <div class="mb-3">
        <label for="role" class="form-label">Vai trò</label>
        <select class="form-select" id="role" name="role" required>
            <?php if ($_SESSION['role'] == 'super_admin') { ?>
                <option value="super_admin">Super Admin</option>
                <option value="admin">Admin</option>
            <?php } ?>
            <option value="user">User</option>
        </select>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i> Thêm tài khoản</button>
    <a href="index.php?controller=user&action=manageUsers" class="btn btn-secondary"><i class="bi bi-arrow-left me-1"></i> Quay lại</a>
</form>

<?php include 'views/layouts/footer.php'; ?>