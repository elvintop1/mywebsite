<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Quản lý liên hệ</h1>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Họ và tên</th>
            <th>Email</th>
            <th>Số điện thoại</th>
            <th>Tin nhắn</th>
            <th>Ngày gửi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($contacts as $contact) { ?>
            <tr>
                <td><?php echo $contact['id']; ?></td>
                <td><?php echo htmlspecialchars($contact['name']); ?></td>
                <td><?php echo htmlspecialchars($contact['email']); ?></td>
                <td><?php echo htmlspecialchars($contact['phone']); ?></td>
                <td><?php echo htmlspecialchars($contact['message']); ?></td>
                <td><?php echo $contact['created_at']; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
        <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
            <a class="page-link" href="index.php?controller=contact&action=manage&page=<?php echo $page - 1; ?>" aria-label="Previous">
                <span aria-hidden="true">«</span>
            </a>
        </li>

        <li class="page-item <?php echo $page == 1 ? 'active' : ''; ?>">
            <a class="page-link" href="index.php?controller=contact&action=manage&page=1">1</a>
        </li>

        <?php
        if ($page > 3) {
            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        $start = max(2, $page - 1);
        $end = min($totalPages - 1, $page + 1);
        for ($i = $start; $i <= $end; $i++) {
            echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
            echo '<a class="page-link" href="index.php?controller=contact&action=manage&page=' . $i . '">' . $i . '</a>';
            echo '</li>';
        }

        if ($page < $totalPages - 2) {
            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        if ($totalPages > 1) {
            echo '<li class="page-item ' . ($page == $totalPages ? 'active' : '') . '">';
            echo '<a class="page-link" href="index.php?controller=contact&action=manage&page=' . $totalPages . '">' . $totalPages . '</a>';
            echo '</li>';
        }
        ?>

        <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
            <a class="page-link" href="index.php?controller=contact&action=manage&page=<?php echo $page + 1; ?>" aria-label="Next">
                <span aria-hidden="true">»</span>
            </a>
        </li>
    </ul>
</nav>

<?php include 'views/layouts/footer.php'; ?>