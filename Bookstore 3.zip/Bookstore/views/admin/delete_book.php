<?php include 'views/layouts/header.php'; ?>

<h1>Xóa sách</h1>
<p>Bạn có chắc chắn muốn xóa sách "<strong><?php echo $book['title']; ?></strong>" không?</p>
<form method="POST" id="deleteBookForm">
    <button type="submit" class="btn btn-danger">Xóa</button>
    <a href="index.php?controller=user&action=dashboard" class="btn btn-secondary">Hủy</a>
</form>

<?php include 'views/layouts/footer.php'; ?>