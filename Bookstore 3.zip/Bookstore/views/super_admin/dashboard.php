<?php include 'views/layouts/header.php'; ?>

<h1 class="mb-4">Super Admin Dashboard</h1>
<a href="index.php?controller=user&action=manageUsers" class="btn btn-primary mb-3"><i class="bi bi-person-fill me-1"></i> Quản lý tài khoản</a>

<?php include 'views/layouts/footer.php'; ?>