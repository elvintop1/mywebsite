<div class="row">
    <div class="col-md-8">
        <h2><?php echo $book['title']; ?></h2>
        <p><strong>Tác giả:</strong> <?php echo $book['author']; ?></p>
        <p><strong>Giá:</strong> <?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</p>
        <p><strong>Mô tả:</strong> <?php echo $book['description']; ?></p>
        <a href="?action=index" class="btn btn-secondary">Quay lại</a>
    </div>
</div>