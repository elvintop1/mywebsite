<?php include 'views/layouts/header.php'; ?>
<?php if (isset($_GET['keyword'])): ?>
    <?php
    $keyword = filter_var($_GET['keyword'], FILTER_SANITIZE_STRING);
    $bookController = new BookController();
    $searchResults = $bookController->search($keyword); // Reuse the search method
    ?>
    <div class="mt-5">
        <h2 class="text-2xl font-bold mb-4 text-gray-800">Kết Quả Tìm Kiếm: "<?php echo htmlspecialchars($keyword); ?>"</h2>
        <?php if (empty($searchResults)): ?>
            <p class="text-gray-600">Không tìm thấy sách nào phù hợp với từ khóa "<?php echo htmlspecialchars($keyword); ?>".</p>
        <?php else: ?>
            <div class="row">
                <?php foreach ($searchResults as $book): ?>
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($book['image']); ?>" class="card-img-top" loading="lazy" alt="<?php echo htmlspecialchars($book['title']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($book['title']); ?></h5>
                                <p class="card-text">Tác giả: <?php echo htmlspecialchars($book['author']); ?></p>
                                <p class="card-text text-danger"><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</p>
                                <div class="d-flex gap-2">
                                    <a href="index.php?controller=book&action=show&id=<?php echo $book['id']; ?>" class="btn btn-primary"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                                    <button class="btn btn-outline-secondary add-to-cart" data-id="<?php echo $book['id']; ?>"><i class="bi bi-cart-plus-fill"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="banner-section">
    <div class="banner-content text-center text-white">
        <h2 class="fw-bold mb-3 animate__animated animate__fadeIn">Khuyến Mãi Lớn - Giảm Giá 30%!</h2>
        <p class="mb-4 animate__animated animate__fadeIn animate__delay-1s">Mua sắm ngay hôm nay để nhận ưu đãi đặc biệt cho các tựa sách hot nhất!</p>
        <a href="index.php?controller=book&action=all" class="btn btn-light animate__animated animate__fadeIn animate__delay-2s">Khám Phá Ngay</a>
    </div>
</div>

<!-- Bestseller -->
<h1 class="text-3xl font-bold mb-6 text-gray-800 text-center">Sách Nổi Bật</h1>
<div class="row">
    <?php foreach ($bestsellers as $book): ?>
        <div class="col-md-4 col-sm-6 mb-4">
            <div class="card">
                <img src="<?php echo htmlspecialchars($book['image']); ?>" class="card-img-top" loading="lazy" alt="<?php echo htmlspecialchars($book['title']); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($book['title']); ?></h5>
                    <p class="card-text">Tác giả: <?php echo htmlspecialchars($book['author']); ?></p>
                    <p class="card-text text-danger"><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</p>
                    <div class="d-flex gap-2">
                        <a href="index.php?controller=book&action=show&id=<?php echo $book['id']; ?>" class="btn btn-primary"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                        <button class="btn btn-outline-secondary add-to-cart" data-id="<?php echo $book['id']; ?>"><i class="bi bi-cart-plus-fill"></i></button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php foreach ($booksByCategory as $categoryId => $categoryData): ?>
    <?php if (!empty($categoryData['books'])): ?>
        <div class="mt-8">
            <h2 class="text-2xl font-bold mb-4 text-gray-800"><?php echo htmlspecialchars($categoryData['category_name']); ?></h2>
            <div class="row">
                <?php foreach ($categoryData['books'] as $book): ?>
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($book['image']); ?>" class="card-img-top" loading="lazy" alt="<?php echo htmlspecialchars($book['title']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($book['title']); ?></h5>
                                <p class="card-text">Tác giả: <?php echo htmlspecialchars($book['author']); ?></p>
                                <p class="card-text text-danger"><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</p>
                                <div class="d-flex gap-2">
                                    <a href="index.php?controller=book&action=show&id=<?php echo $book['id']; ?>" class="btn btn-primary"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                                    <button class="btn btn-outline-secondary add-to-cart" data-id="<?php echo $book['id']; ?>"><i class="bi bi-cart-plus-fill"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <!-- Liên kết xem thêm -->
            <div class="text-end mt-3">
                <a href="index.php?controller=book&action=all&categories=<?php echo $categoryId; ?>&page=1" class="btn btn-outline-primary">Xem thêm</a>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; ?>

<?php include 'views/layouts/footer.php'; ?>
