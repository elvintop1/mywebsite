<?php include 'views/layouts/header.php'; ?>

<h1 class="text-center mb-4">Kết quả tìm kiếm cho: "<?php echo htmlspecialchars($keyword); ?>"</h1>

<?php if (empty($books)) { ?>
    <p class="text-center">Không tìm thấy sách nào phù hợp với từ khóa "<?php echo htmlspecialchars($keyword); ?>".</p>
    <div class="text-center">
        <a href="index.php?controller=book&action=index" class="btn btn-primary"><i class="bi bi-arrow-left me-1"></i> Quay lại trang chủ</a>
    </div>
<?php } else { ?>
    <div class="row">
        <?php foreach ($books as $book) { ?>
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="card">
                    <img src="<?php echo $book['image']; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $book['title']; ?></h5>
                        <p class="card-text">Tác giả: <?php echo $book['author']; ?></p>
                        <p class="card-text text-muted">Thể loại: <?php echo $book['category_name']; ?></p>
                        <p class="card-text text-danger"><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</p>
                        <a href="index.php?controller=book&action=show&id=<?php echo $book['id']; ?>" class="btn btn-primary"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                        <button class="btn btn-outline-secondary add-to-cart" data-id="<?php echo $book['id']; ?>"><i class="bi bi-cart-plus-fill"></i></button>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Phân trang -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <!-- Nút Previous -->
            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="index.php?controller=book&action=searchResults&keyword=<?php echo urlencode($keyword); ?>&page=<?php echo $page - 1; ?>" aria-label="Previous">
                    <span aria-hidden="true">«</span>
                </a>
            </li>

            <!-- Trang đầu -->
            <li class="page-item <?php echo $page == 1 ? 'active' : ''; ?>">
                <a class="page-link" href="index.php?controller=book&action=searchResults&keyword=<?php echo urlencode($keyword); ?>&page=1">1</a>
            </li>

            <?php
            if ($page > 3) {
                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }

            $start = max(2, $page - 1);
            $end = min($totalPages - 1, $page + 1);
            for ($i = $start; $i <= $end; $i++) {
                echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
                echo '<a class="page-link" href="index.php?controller=book&action=searchResults&keyword=' . urlencode($keyword) . '&page=' . $i . '">' . $i . '</a>';
                echo '</li>';
            }

            if ($page < $totalPages - 2) {
                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }

            if ($totalPages > 1) {
                echo '<li class="page-item ' . ($page == $totalPages ? 'active' : '') . '">';
                echo '<a class="page-link" href="index.php?controller=book&action=searchResults&keyword=' . urlencode($keyword) . '&page=' . $totalPages . '">' . $totalPages . '</a>';
                echo '</li>';
            }
            ?>

            <!-- Nút Next -->
            <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                <a class="page-link" href="index.php?controller=book&action=searchResults&keyword=<?php echo urlencode($keyword); ?>&page=<?php echo $page + 1; ?>" aria-label="Next">
                    <span aria-hidden="true">»</span>
                </a>
            </li>
        </ul>
    </nav>
<?php } ?>

<?php include 'views/layouts/footer.php'; ?>