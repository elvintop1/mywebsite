<?php include 'views/layouts/header.php'; ?>

<div class="row book-detail">
    <div class="col-md-6">
        <div class="d-flex flex-column align-items-center">
            <img src="<?php echo htmlspecialchars($book['image']); ?>" class="img-fluid mb-3" alt="<?php echo htmlspecialchars($book['title']); ?>" style="max-width: 300px;">
            <div class="d-flex justify-content-center">
                <img src="<?php echo htmlspecialchars($book['image']); ?>" class="img-fluid me-2" alt="Back cover" style="max-width: 100px;">
                <img src="<?php echo htmlspecialchars($book['image']); ?>" class="img-fluid" alt="Front cover" style="max-width: 100px;">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <h1><?php echo htmlspecialchars($book['title']); ?></h1>
        <p>by <?php echo htmlspecialchars($book['author']); ?></p>
        <p><strong>Thể loại:</strong> <?php echo htmlspecialchars($book['category_name']); ?></p>
        <h3 class="text-danger"><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</h3>
        <div class="d-flex justify-content-between mb-3">
            <button class="btn btn-primary add-to-cart" data-id="<?php echo $book['id']; ?>"><i class="bi bi-cart-plus-fill me-1"></i> Add to Cart</button>
        </div>
    </div>
</div>

<div class="mt-5">
    <h2>Mô tả</h2>
    <p><?php echo htmlspecialchars($book['description']); ?></p>
</div>

<div class="mt-5">
    <h2>Bình luận</h2>
    <div class="comment-section">
        <?php if (isset($_SESSION['user_id'])) { ?>
            <form id="commentForm" class="mb-3">
                <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                <div class="mb-3">
                    <label for="comment" class="form-label">Viết bình luận của bạn:</label>
                    <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary"><i class="bi bi-send-fill me-1"></i> Gửi bình luận</button>
            </form>
        <?php } else { ?>
            <p>Vui lòng <a href="index.php?controller=user&action=login">đăng nhập</a> để viết bình luận.</p>
        <?php } ?>

        <div id="commentsSection">
            <?php if (empty($comments)) { ?>
                <p>Chưa có bình luận nào.</p>
            <?php } else { ?>
                <?php foreach ($comments as $comment) { ?>
                    <div class="border p-3 mb-2">
                        <strong><?php echo htmlspecialchars($comment['full_name']); ?> (@<?php echo htmlspecialchars($comment['username']); ?>)</strong>
                        <small class="text-muted"><?php echo $comment['created_at']; ?></small>
                        <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>