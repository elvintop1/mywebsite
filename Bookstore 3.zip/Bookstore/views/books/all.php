<?php include 'views/layouts/header.php'; ?>

<!-- Banner -->
<div class="banner-section">
    <div class="banner-content text-center text-white">
        <h2 class="fw-bold mb-3 animate__animated animate__fadeIn">Khuyến Mãi Lớn - Giảm Giá 30%!</h2>
        <p class="mb-4 animate__animated animate__fadeIn animate__delay-1s">Mua sắm ngay hôm nay để nhận ưu đãi đặc biệt cho các tựa sách hot nhất!</p>
        <a href="index.php?controller=book&action=all" class="btn btn-light animate__animated animate__fadeIn animate__delay-2s">Khám Phá Ngay</a>
    </div>
</div>

<div class="container py-8">
    <div class="row">
        <div class="col-md-3 col-lg-2 mb-4 filter-section">
            <h5 class="mb-3 d-flex justify-content-between align-items-center">
                Bộ lọc
                <button class="btn btn-outline-secondary btn-sm d-md-none toggle-filter" id="toggle-filter">
                    <i class="bi bi-chevron-down"></i>
                </button>
            </h5>
            <div class="filter-content">
                <form method="GET" action="index.php" id="filter-form">
                    <input type="hidden" name="controller" value="book">
                    <input type="hidden" name="action" value="all">
                    <input type="hidden" name="page" value="1">

                    <h6 class="mb-2">Thể loại</h6>
                    <?php foreach ($categories as $category) { ?>
                        <div class="form-check filter-checkbox">
                            <input class="form-check-input" type="checkbox" name="categories[]" value="<?php echo $category['id']; ?>" id="category_<?php echo $category['id']; ?>" <?php echo in_array($category['id'], $category_ids) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="category_<?php echo $category['id']; ?>">
                                <?php echo htmlspecialchars($category['name']); ?>
                            </label>
                        </div>
                    <?php } ?>

                    <!-- Sắp xếp -->
                    <h6 class="mt-4 mb-2">Sắp xếp</h6>
                    <select name="sort" class="form-select mb-3" id="sort-select">
                        <option value="title_asc" <?php echo $sort == 'title_asc' ? 'selected' : ''; ?>>Tên sách (A-Z)</option>
                        <option value="title_desc" <?php echo $sort == 'title_desc' ? 'selected' : ''; ?>>Tên sách (Z-A)</option>
                        <option value="price_asc" <?php echo $sort == 'price_asc' ? 'selected' : ''; ?>>Giá (Thấp đến Cao)</option>
                        <option value="price_desc" <?php echo $sort == 'price_desc' ? 'selected' : ''; ?>>Giá (Cao đến Thấp)</option>
                        <option value="date_desc" <?php echo $sort == 'date_desc' ? 'selected' : ''; ?>>Mới nhất</option>
                        <option value="date_asc" <?php echo $sort == 'date_asc' ? 'selected' : ''; ?>>Cũ nhất</option>
                    </select>

                    <button type="submit" class="btn btn-primary w-100 mb-2">Áp dụng</button>
                    <button type="button" class="btn btn-secondary w-100" id="clear-filters">Xóa bộ lọc</button>
                </form>
            </div>
        </div>

        <div class="col-md-9 col-lg-10">
            <div class="custom-search text-center mb-5">
                <input type="text" placeholder="Tìm kiếm sách..." name="keyword" id="search-all-input" value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>">
                <i class="bi bi-search ms-2"></i>
            </div>

            <div class="row" id="book-list">
                <?php if (empty($books)) { ?>
                    <p class="text-center">Không có sách nào trong thể loại này.</p>
                <?php } else { ?>
                    <?php foreach ($books as $book) { ?>
                        <div class="col-md-4 col-sm-6 mb-4 book-item" data-book-id="<?php echo $book['id']; ?>">
                            <div class="card">
                                <img src="<?php echo $book['image']; ?>" class="card-img-top" alt="<?php echo $book['title']; ?>">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $book['title']; ?></h5>
                                    <p class="card-text">Tác giả: <?php echo $book['author']; ?></p>
                                    <p class="card-text text-muted">Thể loại: <?php echo $book['category_name']; ?></p>
                                    <p class="card-text text-danger"><?php echo number_format($book['price'], 0, ',', '.'); ?> VNĐ</p>
                                    <div class="d-flex gap-2">
                                        <a href="index.php?controller=book&action=show&id=<?php echo $book['id']; ?>" class="btn btn-primary"><i class="bi bi-eye-fill me-1"></i> Xem chi tiết</a>
                                        <button class="btn btn-outline-secondary add-to-cart" data-id="<?php echo $book['id']; ?>"><i class="bi bi-cart-plus-fill"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php } ?>
            </div>

            <nav aria-label="Page navigation" id="pagination">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="index.php?controller=book&action=all&<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" aria-label="Previous">
                            <span aria-hidden="true">«</span>
                        </a>
                    </li>
                    <li class="page-item <?php echo $page == 1 ? 'active' : ''; ?>">
                        <a class="page-link" href="index.php?controller=book&action=all&<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>">1</a>
                    </li>
                    <?php
                    if ($page > 3) {
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }
                    $start = max(2, $page - 1);
                    $end = min($totalPages - 1, $page + 1);
                    for ($i = $start; $i <= $end; $i++) {
                        echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">';
                        echo '<a class="page-link" href="index.php?controller=book&action=all&' . http_build_query(array_merge($_GET, ['page' => $i])) . '">' . $i . '</a>';
                        echo '</li>';
                    }
                    if ($page < $totalPages - 2) {
                        echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                    }
                    if ($totalPages > 1) {
                        echo '<li class="page-item ' . ($page == $totalPages ? 'active' : '') . '">';
                        echo '<a class="page-link" href="index.php?controller=book&action=all&' . http_build_query(array_merge($_GET, ['page' => $totalPages])) . '">' . $totalPages . '</a>';
                        echo '</li>';
                    }
                    ?>
                    <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="index.php?controller=book&action=all&<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" aria-label="Next">
                            <span aria-hidden="true">»</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>
