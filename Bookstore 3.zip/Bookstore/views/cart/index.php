<?php include 'views/layouts/header.php'; ?>

<div class="container">
    <h1 class="text-center mb-4">Giỏ hàng của bạn</h1>
    <?php if (isset($_SESSION['error'])) { ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['error']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php } ?>
    <?php if (empty($cartItems)) { ?>
        <p class="text-center">Giỏ hàng của bạn đang trống.</p>
    <?php } else { ?>
        <!-- Debug: Ghi log cartItems trước khi hiển thị -->
        <?php error_log("Cart Items in View: " . print_r($cartItems, true)); ?>
        <!-- Sao chép từng phần tử của $cartItems vào một mảng mới -->
        <?php
        $displayCartItems = [];
        foreach ($cartItems as $index => $cartItem) {
            $displayCartItems[$index] = [
                'image' => $cartItem['image'],  
                'book_id' => $cartItem['book_id'],
                'quantity' => $cartItem['quantity'],
                'title' => $cartItem['title'],
                'author' => $cartItem['author'],
                'price' => $cartItem['price']
            ];
        }
        ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Ảnh</th>
                    <th>Tiêu đề</th>
                    <th>Tác giả</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Tổng cộng</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody id="cart-items">
                <?php for ($i = 0; $i < count($displayCartItems); $i++) { ?>
                    <?php $item = $displayCartItems[$i]; ?>
                    <tr data-book-id="<?php echo $item['book_id']; ?>">
                        <td>
                            <img src="<?php echo htmlspecialchars($item['image'] ?? 'https://via.placeholder.com/80x112?text=Book+Image'); ?>" class="w-16 h-24 object-cover rounded-lg mx-auto" loading="lazy" alt="<?php echo htmlspecialchars($item['title']); ?>">
                        </td>
                        <td><?php echo htmlspecialchars($item['title']); error_log("Displaying book [index $i]: " . $item['title'] . " (book_id: " . $item['book_id'] . ")"); ?></td>
                        <td><?php echo htmlspecialchars($item['author']); ?></td>
                        <td class="text-danger"><?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</td>
                        <td>
                            <button class="btn btn-sm btn-outline-secondary decrease-quantity" data-id="<?php echo $item['book_id']; ?>">-</button>
                            <span class="quantity mx-2"><?php echo $item['quantity']; ?></span>
                            <button class="btn btn-sm btn-outline-secondary increase-quantity" data-id="<?php echo $item['book_id']; ?>">+</button>
                        </td>
                        <td class="subtotal text-danger"><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?> VNĐ</td>
                        <td>
                            <button class="btn btn-sm btn-danger remove-from-cart" data-id="<?php echo $item['book_id']; ?>">Xóa</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" class="text-end"><strong>Tổng cộng:</strong></td>
                    <td id="cart-total" class="text-danger"><?php echo number_format($total, 0, ',', '.'); ?> VNĐ</td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
        <div class="text-end">
            <a href="index.php?controller=user&action=checkout" class="btn btn-success" id="checkout-button">Thanh toán</a>
        </div>

        <!-- Modal xác nhận thanh toán -->
        <!-- <div class="modal fade" id="confirmCheckoutModal" tabindex="-1" aria-labelledby="confirmCheckoutModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="confirmCheckoutModalLabel">Xác nhận thanh toán</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Bạn có chắc chắn muốn thanh toán không?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="button" class="btn btn-primary" id="confirmCheckoutButton">Thanh toán</button>
                    </div>
                </div>
            </div>
        </div> -->
    <?php } ?>
</div>

<?php include 'views/layouts/footer.php'; ?>