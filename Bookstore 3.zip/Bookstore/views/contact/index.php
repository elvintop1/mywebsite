<?php include 'views/layouts/header.php'; ?>

<div class="container-fluid p-0">
    <div class="row g-0">
        <!-- Form liên hệ (bên trái) -->
        <div class="col-md-4 col-lg-3 p-4 bg-dark text-white d-flex align-items-center" style="min-height: 400px;">
            <div class="w-100">
                <h2 class="mb-4">Get In Touch</h2>
                <div class="mb-4">
                    <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-white"><i class="bi bi-behance"></i></a>
                </div>
                <?php if (isset($success)) { ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php } elseif (isset($error)) { ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php } ?>
                <form method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label text-white">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label text-white">Email (example@gmail.com)</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label text-white">Your Message</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-light w-100">SEND</button>
                </form>
            </div>
        </div>

        <!-- Bản đồ (bên phải) -->
        <div class="col-md-8 col-lg-9">
            <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.5053248032486!2d106.65601356941944!3d10.772555560463635!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752ec17709146b%3A0x54a1658a0639d341!2zxJDhuqFpIEjhu41jIELDoWNoIEtob2EgLSAyNjggTMO9IFRoxrDhu51uZyBLaeG7h3Q!5e0!3m2!1svi!2s!4v1745158810128!5m2!1svi!2s"
                style="border:0; width: 100%; height: 500px;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
</div>

<?php include 'views/layouts/footer.php'; ?>