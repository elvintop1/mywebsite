<?php
$password = 'admin123'; // Mật khẩu bạn muốn mã hóa
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
echo $hashed_password;
?>