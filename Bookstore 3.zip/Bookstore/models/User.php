<?php
require_once 'config/database.php';

class User {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function checkDuplicate($username, $email, $exclude_id = null) {
        try {
            $query = "SELECT * FROM users WHERE (username = :username OR email = :email)";
            if ($exclude_id !== null) {
                $query .= " AND id != :id";
            }
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $email);
            if ($exclude_id !== null) {
                $stmt->bindParam(':id', $exclude_id, PDO::PARAM_INT);
            }
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC) !== false;
        } catch (PDOException $e) {
            error_log("CheckDuplicate error: " . $e->getMessage());
            return false;
        }
    }

    

    public function login($username, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username = :username AND deleted_at IS NULL");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password'])) {
            $this->updateLastLogin($user['id']);
            return $user;
        }
        return false;
    }

    public function register($username, $password, $email, $full_name, $role = 'user', $address = null, $phone = null) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE username = :username OR email = :email");
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            if ($stmt->fetch()) {
                return false; 
            }
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("INSERT INTO users (username, password, email, full_name, role, address, phone) VALUES (:username, :password, :email, :full_name, :role, :address, :phone)");
            $result = $stmt->execute([
                'username' => $username,
                'password' => $hashed_password,
                'email' => $email,
                'full_name' => $full_name,
                'role' => $role,
                'address' => $address,
                'phone' => $phone
            ]);
            if (!$result) {
                error_log("Register error for username=$username: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("register: Successfully registered user with username=$username");
            return true;
        } catch (PDOException $e) {
            error_log("Register exception for username=$username: " . $e->getMessage());
            return false;
        }
    }

    public function getOrders($user_id) {
        $stmt = $this->conn->prepare("SELECT * FROM orders WHERE user_id = :user_id ORDER BY created_at DESC");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getOrderDetails($order_id) {
        $stmt = $this->conn->prepare("SELECT od.*, b.title, b.image FROM order_details od JOIN books b ON od.book_id = b.id WHERE od.order_id = :order_id");
        $stmt->bindParam(':order_id', $order_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getOrderById($order_id) {
        $stmt = $this->conn->prepare("SELECT * FROM orders WHERE id = :order_id");
        $stmt->bindParam(':order_id', $order_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllUsers($role = null, $page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        $query = "SELECT * FROM users WHERE deleted_at IS NULL";
        $params = [];
        if ($role) {
            $query .= " AND role = :role";
            $params['role'] = $role;
        }
        $query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
        $stmt = $this->conn->prepare($query);
        if ($role) {
            $stmt->bindParam(':role', $params['role']);
        }
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotalUsers($role = null) {
        $query = "SELECT COUNT(*) FROM users WHERE deleted_at IS NULL";
        $params = [];
        if ($role) {
            $query .= " AND role = :role";
            $params['role'] = $role;
        }
        $stmt = $this->conn->prepare($query);
        if ($role) {
            $stmt->bindParam(':role', $params['role']);
        }
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    public function getUserById($user_id) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = :id AND deleted_at IS NULL");
        $stmt->bindParam(':id', $user_id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateUser($user_id, $username, $email, $full_name, $role, $address = null) {
        try {
            $stmt = $this->conn->prepare("UPDATE users SET username = :username, email = :email, full_name = :full_name, role = :role, address = :address WHERE id = :id AND deleted_at IS NULL");
            $result = $stmt->execute([
                'username' => $username,
                'email' => $email,
                'full_name' => $full_name,
                'role' => $role,
                'address' => $address,
                'id' => $user_id
            ]);
            if (!$result) {
                error_log("UpdateUser error for user_id=$user_id: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("updateUser: Successfully updated user with id=$user_id");
            return true;
        } catch (PDOException $e) {
            error_log("UpdateUser exception for user_id=$user_id: " . $e->getMessage());
            return false;
        }
    }

    public function updateProfile($user_id, $email, $full_name) {
        try {
            $stmt = $this->conn->prepare("UPDATE users SET email = :email, full_name = :full_name WHERE id = :id AND deleted_at IS NULL");
            $result = $stmt->execute([
                'email' => $email,
                'full_name' => $full_name,
                'id' => $user_id
            ]);
            if (!$result) {
                error_log("UpdateProfile error for user_id=$user_id: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("updateProfile: Successfully updated profile for user with id=$user_id");
            return true;
        } catch (PDOException $e) {
            error_log("UpdateProfile exception for user_id=$user_id: " . $e->getMessage());
            return false;
        }
    }

    public function deleteUser($user_id) {
        try {
            $stmt = $this->conn->prepare("UPDATE users SET deleted_at = NOW() WHERE id = :id AND deleted_at IS NULL");
            $stmt->bindParam(':id', $user_id);
            $result = $stmt->execute();
            if (!$result) {
                error_log("SoftDeleteUser error for user_id=$user_id: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            if ($stmt->rowCount() === 0) {
                error_log("SoftDeleteUser: No user found with id=$user_id or user already deleted.");
                return false;
            }
            error_log("softDeleteUser: Successfully soft deleted user with id=$user_id");
            return true;
        } catch (PDOException $e) {
            error_log("SoftDeleteUser exception for user_id=$user_id: " . $e->getMessage());
            return false;
        }
    }

    public function updateLastLogin($user_id) {
        $stmt = $this->conn->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
        $stmt->execute(['id' => $user_id]);
    }
}
?>