<?php
require_once 'config/database.php';

class Order {
    public $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Tạo đơn hàng
    public function createOrder($user_id, $total, $cart, $address, $email) {
        $stmt = $this->conn->prepare("INSERT INTO orders (user_id, total, address, email) VALUES (:user_id, :total, :address, :email)");
        $stmt->execute(['user_id' => $user_id, 'total' => $total, 'address' => $address, 'email' => $email]);
        $order_id = $this->conn->lastInsertId();

        foreach ($cart as $book_id => $quantity) {
            $book_stmt = $this->conn->prepare("SELECT price FROM books WHERE id = :id");
            $book_stmt->execute(['id' => $book_id]);
            $price = $book_stmt->fetchColumn();
            $stmt = $this->conn->prepare("INSERT INTO order_details (order_id, book_id, quantity, price) VALUES (:order_id, :book_id, :quantity, :price)");
            $stmt->execute(['order_id' => $order_id, 'book_id' => $book_id, 'quantity' => $quantity, 'price' => $price]);
        }
        return $order_id;
    }

    // Lấy tất cả đơn hàng
    public function getAllOrders() {
        $stmt = $this->conn->prepare("
            SELECT o.*, u.username AS customer_name 
            FROM orders o 
            JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lấy đơn hàng theo ID
    public function getOrderById($orderId) {
        $stmt = $this->conn->prepare("
            SELECT o.*, u.username AS customer_name 
            FROM orders o 
            JOIN users u ON o.user_id = u.id 
            WHERE o.id = :id
        ");
        $stmt->execute(['id' => $orderId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Lấy danh sách sản phẩm trong đơn hàng
    public function getOrderItems($orderId) {
        $stmt = $this->conn->prepare("
            SELECT od.*, b.title, b.image, b.price 
            FROM order_details od 
            JOIN books b ON od.book_id = b.id 
            WHERE od.order_id = :order_id
        ");
        $stmt->execute(['order_id' => $orderId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Cập nhật trạng thái đơn hàng
    public function updateOrderStatus($orderId, $status) {
        $stmt = $this->conn->prepare("UPDATE orders SET status = :status WHERE id = :id");
        $stmt->execute(['status' => $status, 'id' => $orderId]);
        return $stmt->rowCount() > 0;
    }
}