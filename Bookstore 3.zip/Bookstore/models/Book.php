<?php
require_once 'config/database.php';

class Book {
    public $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
        if (!$this->conn) {
            error_log("Failed to connect to database in Book model");
            throw new Exception("Không thể kết nối đến cơ sở dữ liệu.");
        }
    }

    public function getAllBooks($page = 1, $limit = 10) {
        try {
            $page = max(1, (int)$page);
            $limit = max(1, (int)$limit);
            $offset = ($page - 1) * $limit;
            $stmt = $this->conn->prepare("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id WHERE b.deleted_at IS NULL LIMIT :limit OFFSET :offset");
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getAllBooks: Fetched " . count($results) . " books with page=$page, limit=$limit");
            return $results;
        } catch (PDOException $e) {
            error_log("GetAllBooks error: " . $e->getMessage());
            throw new Exception("Không thể tải tất cả sách: " . $e->getMessage());
        }
    }

    public function getTotalBooks($keyword = '') {
        try {
            $query = "SELECT COUNT(*) FROM books WHERE deleted_at IS NULL";
            if (!empty($keyword)) {
                $query .= " AND (title LIKE :keyword OR author LIKE :keyword)";
            }
            $stmt = $this->conn->prepare($query);
            if (!empty($keyword)) {
                $keywordParam = "{$keyword}%";
                $stmt->bindParam(':keyword', $keywordParam);
            }
            $stmt->execute();
            $totalBooks = $stmt->fetchColumn();
            error_log("getTotalBooks: Total books = $totalBooks (keyword: " . ($keyword ?: 'none') . ")");
            return $totalBooks;
        } catch (PDOException $e) {
            error_log("GetTotalBooks error: " . $e->getMessage());
            throw new Exception("Không thể đếm tổng số sách: " . $e->getMessage());
        }
    }

    public function getBookById($id) {
        try {
            $id = (int)$id;
            $stmt = $this->conn->prepare("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id WHERE b.id = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            error_log("getBookById: Fetched book with id=$id");
            return $result;
        } catch (PDOException $e) {
            error_log("GetBookById error: " . $e->getMessage());
            throw new Exception("Không thể tải sách theo ID: " . $e->getMessage());
        }
    }

    public function addBook($title, $author, $price, $image, $description, $category_id) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO books (title, author, price, image, description, category_id) VALUES (:title, :author, :price, :image, :description, :category_id)");
            $result = $stmt->execute([
                'title' => $title,
                'author' => $author,
                'price' => (float)$price,
                'image' => 'images/'.$image,
                'description' => $description,
                'category_id' => (int)$category_id
            ]);
            if (!$result) {
                error_log("AddBook error: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("addBook: Successfully added book with title='$title'");
            return true;
        } catch (PDOException $e) {
            error_log("AddBook error: " . $e->getMessage());
            return false;
        }
    }

    public function updateBook($id, $title, $author, $price, $image, $description, $category_id) {
        try {
            $stmt = $this->conn->prepare("UPDATE books SET title = :title, author = :author, price = :price, image = :image, description = :description, category_id = :category_id WHERE id = :id");
            $result = $stmt->execute([
                'title' => $title,
                'author' => $author,
                'price' => (float)$price,
                'image' => $image,
                'description' => $description,
                'category_id' => (int)$category_id,
                'id' => (int)$id
            ]);
            if (!$result) {
                error_log("UpdateBook error: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("updateBook: Successfully updated book with id=$id");
            return true;
        } catch (PDOException $e) {
            error_log("UpdateBook error: " . $e->getMessage());
            return false;
        }
    }

    public function deleteBook($id) {
        try {
            // Đánh dấu sách là đã xóa (soft delete)
            $stmt = $this->conn->prepare("UPDATE books SET deleted_at = NOW() WHERE id = :id AND deleted_at IS NULL");
            $result = $stmt->execute(['id' => (int)$id]);
            if (!$result) {
                error_log("DeleteBook (soft delete) error: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            if ($stmt->rowCount() === 0) {
                error_log("DeleteBook: No book found with id=$id or already deleted.");
                return false;
            }
            error_log("deleteBook: Successfully soft deleted book with id=$id");
    
            // Xóa các mục trong giỏ hàng liên quan đến sách
            $stmt = $this->conn->prepare("DELETE FROM cart WHERE book_id = :id");
            $stmt->execute(['id' => (int)$id]);
            error_log("DeleteBook: Successfully deleted from cart for book_id=$id");
    
            // Xóa các bình luận liên quan đến sách
            $stmt = $this->conn->prepare("DELETE FROM comments WHERE book_id = :id");
            $stmt->execute(['id' => (int)$id]);
            error_log("DeleteBook: Successfully deleted from comments for book_id=$id");
    
            return true;
        } catch (PDOException $e) {
            error_log("DeleteBook: Exception for book_id=$id: " . $e->getMessage());
            return false;
        }
    }

    public function getComments($book_id) {
        try {
            $stmt = $this->conn->prepare("SELECT c.*, u.username, u.full_name FROM comments c JOIN users u ON c.user_id = u.id WHERE c.book_id = :book_id ORDER BY c.created_at DESC");
            $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getComments: Fetched " . count($results) . " comments for book_id=$book_id");
            return $results;
        } catch (PDOException $e) {
            error_log("GetComments error: " . $e->getMessage());
            throw new Exception("Không thể tải bình luận: " . $e->getMessage());
        }
    }

    public function addComment($book_id, $user_id, $comment) {
        try {
            $stmt = $this->conn->prepare("INSERT INTO comments (book_id, user_id, comment) VALUES (:book_id, :user_id, :comment)");
            $result = $stmt->execute([
                'book_id' => (int)$book_id,
                'user_id' => (int)$user_id,
                'comment' => $comment
            ]);
            if (!$result) {
                error_log("AddComment error: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("addComment: Successfully added comment for book_id=$book_id, user_id=$user_id");
            return true;
        } catch (PDOException $e) {
            error_log("AddComment error: " . $e->getMessage());
            return false;
        }
    }

    public function getCategories() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM categories");
            $stmt->execute();
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getCategories: Fetched " . count($categories) . " categories");
            return $categories;
        } catch (PDOException $e) {
            error_log("GetCategories error: " . $e->getMessage());
            throw new Exception("Không thể tải danh mục: " . $e->getMessage());
        }
    }

    public function getBooksByCategory($category_id, $page = 1, $limit = 10) {
        try {
            $page = max(1, (int)$page);
            $limit = max(1, (int)$limit);
            $offset = ($page - 1) * $limit;
            if ($category_id === 'all') {
                return $this->getAllBooks($page, $limit);
            }
            $stmt = $this->conn->prepare("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id WHERE b.category_id = :category_id LIMIT :limit OFFSET :offset");
            $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getBooksByCategory: Fetched " . count($results) . " books for category_id=$category_id");
            return $results;
        } catch (PDOException $e) {
            error_log("GetBooksByCategory error: " . $e->getMessage());
            throw new Exception("Không thể tải sách theo danh mục: " . $e->getMessage());
        }
    }

    public function getTotalBooksByCategory($category_id) {
        try {
            if ($category_id === 'all') {
                return $this->getTotalBooks();
            }
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM books b JOIN categories c ON b.category_id = c.id WHERE b.category_id = :category_id");
            $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
            $stmt->execute();
            $total = $stmt->fetchColumn();
            error_log("getTotalBooksByCategory: Total books in category $category_id = $total");
            return $total;
        } catch (PDOException $e) {
            error_log("GetTotalBooksByCategory error: " . $e->getMessage());
            throw new Exception("Không thể đếm sách theo danh mục: " . $e->getMessage());
        }
    }

    public function getBestsellers() {
        try {
            $stmt = $this->conn->prepare("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id LIMIT 3");
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getBestsellers: Fetched " . count($results) . " bestsellers");
            return $results;
        } catch (PDOException $e) {
            error_log("GetBestsellers error: " . $e->getMessage());
            throw new Exception("Không thể tải sách nổi bật: " . $e->getMessage());
        }
    }

    public function getBooksByCategoryForHomepage($category_id, $limit = 4) {
        try {
            $stmt = $this->conn->prepare("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id WHERE b.category_id = :category_id LIMIT :limit");
            $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getBooksByCategoryForHomepage: Fetched " . count($results) . " books for category_id=$category_id");
            return $results;
        } catch (PDOException $e) {
            error_log("GetBooksByCategoryForHomepage error: " . $e->getMessage());
            throw new Exception("Không thể tải sách cho trang chủ: " . $e->getMessage());
        }
    }

    public function getFilteredBooks($category_ids = [], $sort = 'title_asc', $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            $query = "SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id";
            $params = [];
            if (!empty($category_ids)) {
                $placeholders = [];
                foreach ($category_ids as $index => $id) {
                    $placeholders[] = ":cat_$index";
                    $params[":cat_$index"] = $id;
                }
                $query .= " WHERE b.category_id IN (" . implode(',', $placeholders) . ")";
            }
            switch ($sort) {
                case 'price_asc':
                    $query .= " ORDER BY b.price ASC";
                    break;
                case 'price_desc':
                    $query .= " ORDER BY b.price DESC";
                    break;
                case 'title_asc':
                    $query .= " ORDER BY b.title ASC";
                    break;
                case 'title_desc':
                    $query .= " ORDER BY b.title DESC";
                    break;
                case 'date_asc':
                    $query .= " ORDER BY b.updated_at ASC";
                    break;
                case 'date_desc':
                    $query .= " ORDER BY b.updated_at DESC";
                    break;
                default:
                    $query .= " ORDER BY b.title ASC";
            }
            $query .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = $limit;
            $params[':offset'] = $offset;

            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getFilteredBooks: Fetched " . count($results) . " books with categories=" . implode(',', $category_ids));
            return $results;
        } catch (PDOException $e) {
            error_log("GetFilteredBooks error: " . $e->getMessage());
            throw new Exception("Không thể tải sách với bộ lọc: " . $e->getMessage());
        }
    }

    public function getTotalFilteredBooks($category_ids = []) {
        try {
            $query = "SELECT COUNT(*) FROM books b JOIN categories c ON b.category_id = c.id";
            $params = [];
            if (!empty($category_ids)) {
                $placeholders = [];
                foreach ($category_ids as $index => $id) {
                    $placeholders[] = ":cat_$index";
                    $params[":cat_$index"] = $id;
                }
                $query .= " WHERE b.category_id IN (" . implode(',', $placeholders) . ")";
            }
            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            }
            $stmt->execute();
            $total = $stmt->fetchColumn();
            error_log("getTotalFilteredBooks: Total books with categories=" . implode(',', $category_ids) . " = $total");
            return $total;
        } catch (PDOException $e) {
            error_log("GetTotalFilteredBooks error: " . $e->getMessage());
            throw new Exception("Không thể đếm sách với bộ lọc: " . $e->getMessage());
        }
    }

    public function getCartItems($user_id) {
        try {
            $stmt = $this->conn->prepare("SELECT c.book_id, c.quantity, b.title, b.author, b.price, b.image
                                         FROM cart c 
                                         JOIN books b ON c.book_id = b.id 
                                         WHERE c.user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("getCartItems: Fetched " . count($results) . " cart items for user_id=$user_id");
            return $results;
        } catch (PDOException $e) {
            error_log("GetCartItems error: " . $e->getMessage());
            throw new Exception("Không thể tải giỏ hàng: " . $e->getMessage());
        }
    }

    public function addToCart($user_id, $book_id) {
        try {
            $stmt = $this->conn->prepare("SELECT quantity FROM cart WHERE user_id = :user_id AND book_id = :book_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
            $stmt->execute();
            $item = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($item) {
                $newQuantity = $item['quantity'] + 1;
                $stmt = $this->conn->prepare("UPDATE cart SET quantity = :quantity, updated_at = NOW() WHERE user_id = :user_id AND book_id = :book_id");
                $stmt->bindParam(':quantity', $newQuantity, PDO::PARAM_INT);
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
                $result = $stmt->execute();
                if (!$result) {
                    error_log("Failed to update cart for user_id $user_id, book_id $book_id: " . print_r($stmt->errorInfo(), true));
                    return false;
                }
            } else {
                $stmt = $this->conn->prepare("INSERT INTO cart (user_id, book_id, quantity) VALUES (:user_id, :book_id, 1)");
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
                $result = $stmt->execute();
                if (!$result) {
                    error_log("Failed to insert into cart for user_id $user_id, book_id $book_id: " . print_r($stmt->errorInfo(), true));
                    return false;
                }
            }
            error_log("addToCart: Successfully added/updated cart for user_id=$user_id, book_id=$book_id");
            return true;
        } catch (PDOException $e) {
            error_log("AddToCart error: " . $e->getMessage());
            return false;
        }
    }

    public function removeFromCart($user_id, $book_id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM cart WHERE user_id = :user_id AND book_id = :book_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
            $result = $stmt->execute();
            if (!$result) {
                error_log("RemoveFromCart error: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("removeFromCart: Successfully removed from cart for user_id=$user_id, book_id=$book_id");
            return true;
        } catch (PDOException $e) {
            error_log("RemoveFromCart error: " . $e->getMessage());
            return false;
        }
    }

    public function updateCartQuantity($user_id, $book_id, $change) {
        try {
            $stmt = $this->conn->prepare("SELECT quantity FROM cart WHERE user_id = :user_id AND book_id = :book_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
            $stmt->execute();
            $item = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($item) {
                $newQuantity = $item['quantity'] + $change;
                if ($newQuantity <= 0) {
                    return $this->removeFromCart($user_id, $book_id);
                } else {
                    $stmt = $this->conn->prepare("UPDATE cart SET quantity = :quantity, updated_at = NOW() WHERE user_id = :user_id AND book_id = :book_id");
                    $stmt->bindParam(':quantity', $newQuantity, PDO::PARAM_INT);
                    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
                    $result = $stmt->execute();
                    if (!$result) {
                        error_log("UpdateCartQuantity error: " . print_r($stmt->errorInfo(), true));
                        return false;
                    }
                    error_log("updateCartQuantity: Updated quantity to $newQuantity for user_id=$user_id, book_id=$book_id");
                    return true;
                }
            }
            return false;
        } catch (PDOException $e) {
            error_log("UpdateCartQuantity error: " . $e->getMessage());
            return false;
        }
    }

    public function getCartItemQuantity($user_id, $book_id) {
        try {
            $stmt = $this->conn->prepare("SELECT quantity FROM cart WHERE user_id = :user_id AND book_id = :book_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
            $stmt->execute();
            $item = $stmt->fetch(PDO::FETCH_ASSOC);
            $quantity = $item ? $item['quantity'] : 0;
            error_log("getCartItemQuantity: Quantity for user_id=$user_id, book_id=$book_id = $quantity");
            return $quantity;
        } catch (PDOException $e) {
            error_log("GetCartItemQuantity error: " . $e->getMessage());
            return 0;
        }
    }

    public function isCartEmpty($user_id) {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM cart WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->execute();
            $count = $stmt->fetchColumn();
            error_log("isCartEmpty: Cart for user_id=$user_id has $count items");
            return $count == 0;
        } catch (PDOException $e) {
            error_log("IsCartEmpty error: " . $e->getMessage());
            return true; // Assume empty on error
        }
    }

    public function clearCart($user_id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM cart WHERE user_id = :user_id");
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $result = $stmt->execute();
            if (!$result) {
                error_log("ClearCart error: " . print_r($stmt->errorInfo(), true));
                return false;
            }
            error_log("clearCart: Successfully cleared cart for user_id=$user_id");
            return true;
        } catch (PDOException $e) {
            error_log("ClearCart error: " . $e->getMessage());
            return false;
        }
    }

    public function searchBooks_admin($keyword, $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            $query = "SELECT b.*, c.name as category_name 
                      FROM books b 
                      LEFT JOIN categories c ON b.category_id = c.id 
                      WHERE b.deleted_at IS NULL AND (b.title LIKE :keyword OR b.author LIKE :keyword) 
                      ORDER BY b.id DESC 
                      LIMIT :limit OFFSET :offset";
            $stmt = $this->conn->prepare($query);
            $keywordParam = "{$keyword}%";
            $stmt->bindParam(':keyword', $keywordParam);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("searchBooks_admin: Fetched " . count($results) . " books with keyword='$keyword'");
            return $results;
        } catch (PDOException $e) {
            error_log("SearchBooks_admin error: " . $e->getMessage());
            throw new Exception("Không thể tìm kiếm sách trong admin dashboard: " . $e->getMessage());
        }
    }

    public function searchBooks($keyword, $limit = 5, $page = 1) {
        try {
            $keyword = "$keyword%";
            $offset = ($page - 1) * $limit;
            $stmt = $this->conn->prepare("SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id WHERE LOWER(b.title) LIKE :keyword OR LOWER(b.author) LIKE :keyword LIMIT :limit OFFSET :offset");
            $stmt->bindParam(':keyword', $keyword);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("searchBooks: Fetched " . count($results) . " books with keyword='$keyword'");
            return $results;
        } catch (PDOException $e) {
            error_log("SearchBooks error: " . $e->getMessage());
            throw new Exception("Không thể tìm kiếm sách: " . $e->getMessage());
        }
    }

    public function getTotalBooksByKeyword($keyword) {
        try {
            $keyword = "$keyword%";
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM books WHERE LOWER(title) LIKE :keyword OR LOWER(author) LIKE :keyword");
            $stmt->bindParam(':keyword', $keyword);
            $stmt->execute();
            $total = $stmt->fetchColumn();
            error_log("getTotalBooksByKeyword: Total books with keyword='$keyword' = $total");
            return $total;
        } catch (PDOException $e) {
            error_log("GetTotalBooksByKeyword error: " . $e->getMessage());
            throw new Exception("Không thể đếm sách theo từ khóa: " . $e->getMessage());
        }
    }

    public function searchBooksWithFilters($keyword, $category_ids = [], $sort = 'title_asc', $page = 1, $limit = 10) {
        try {
            // Debug: Check total rows in books and categories tables
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM books");
            $stmt->execute();
            $totalBooksInTable = $stmt->fetchColumn();
            error_log("searchBooksWithFilters Debug: Total books in books table = $totalBooksInTable");

            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM categories");
            $stmt->execute();
            $totalCategories = $stmt->fetchColumn();
            error_log("searchBooksWithFilters Debug: Total categories in categories table = $totalCategories");

            // Debug: Check distinct category_id values in books
            $stmt = $this->conn->prepare("SELECT DISTINCT category_id FROM books");
            $stmt->execute();
            $distinctCategoryIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
            error_log("searchBooksWithFilters Debug: Distinct category_id values in books = " . implode(',', $distinctCategoryIds));

            $keyword = "$keyword%";
            $offset = ($page - 1) * $limit;
            $query = "SELECT b.*, c.name AS category_name FROM books b JOIN categories c ON b.category_id = c.id WHERE (LOWER(b.title) LIKE :keyword OR LOWER(b.author) LIKE :keyword)";
            $params = [':keyword' => $keyword];

            if (!empty($category_ids)) {
                $placeholders = [];
                foreach ($category_ids as $index => $id) {
                    $placeholders[] = ":cat_$index";
                    $params[":cat_$index"] = $id;
                }
                $query .= " AND b.category_id IN (" . implode(',', $placeholders) . ")";
            }

            switch ($sort) {
                case 'price_asc':
                    $query .= " ORDER BY b.price ASC";
                    break;
                case 'price_desc':
                    $query .= " ORDER BY b.price DESC";
                    break;
                case 'title_asc':
                    $query .= " ORDER BY b.title ASC";
                    break;
                case 'title_desc':
                    $query .= " ORDER BY b.title DESC";
                    break;
                case 'date_asc':
                    $query .= " ORDER BY b.updated_at ASC";
                    break;
                case 'date_desc':
                    $query .= " ORDER BY b.updated_at DESC";
                    break;
                default:
                    $query .= " ORDER BY b.title ASC";
            }

            $query .= " LIMIT :limit OFFSET :offset";
            $params[':limit'] = $limit;
            $params[':offset'] = $offset;

            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            error_log("searchBooksWithFilters Query: $query");
            error_log("searchBooksWithFilters Params: " . json_encode($params));
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("searchBooksWithFilters: Fetched " . count($results) . " books with keyword='$keyword', categories=" . implode(',', $category_ids));
            return $results;
        } catch (PDOException $e) {
            error_log("SearchBooksWithFilters error: " . $e->getMessage());
            throw new Exception("Không thể tìm kiếm sách với bộ lọc: " . $e->getMessage());
        }
    }

    public function getTotalBooksByKeywordAndFilters($keyword, $category_ids = []) {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM books");
            $stmt->execute();
            $totalBooksInTable = $stmt->fetchColumn();
            error_log("getTotalBooksByKeywordAndFilters Debug: Total books in books table = $totalBooksInTable");

            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM categories");
            $stmt->execute();
            $totalCategories = $stmt->fetchColumn();
            error_log("getTotalBooksByKeywordAndFilters Debug: Total categories in categories table = $totalCategories");

            $stmt = $this->conn->prepare("SELECT DISTINCT category_id FROM books");
            $stmt->execute();
            $distinctCategoryIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
            error_log("getTotalBooksByKeywordAndFilters Debug: Distinct category_id values in books = " . implode(',', $distinctCategoryIds));

            $keyword = "%$keyword%";
            $query = "SELECT COUNT(*) FROM books b JOIN categories c ON b.category_id = c.id WHERE (LOWER(b.title) LIKE :keyword OR LOWER(b.author) LIKE :keyword)";
            $params = [':keyword' => $keyword];

            if (!empty($category_ids)) {
                $placeholders = [];
                foreach ($category_ids as $index => $id) {
                    $placeholders[] = ":cat_$index";
                    $params[":cat_$index"] = $id;
                }
                $query .= " AND b.category_id IN (" . implode(',', $placeholders) . ")";
            }

            $stmt = $this->conn->prepare($query);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            error_log("getTotalBooksByKeywordAndFilters Query: $query");
            error_log("getTotalBooksByKeywordAndFilters Params: " . json_encode($params));
            $stmt->execute();
            $total = $stmt->fetchColumn();
            error_log("getTotalBooksByKeywordAndFilters: Total books with keyword='$keyword', categories=" . implode(',', $category_ids) . " = $total");
            return $total;
        } catch (PDOException $e) {
            error_log("GetTotalBooksByKeywordAndFilters error: " . $e->getMessage());
            throw new Exception("Không thể đếm sách với bộ lọc: " . $e->getMessage());
        }
    }
}
?>