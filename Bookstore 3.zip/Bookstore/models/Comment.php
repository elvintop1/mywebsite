<?php
require_once 'config/database.php';

class Comment {
    public $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getCommentsByBook($book_id) {
        $stmt = $this->conn->prepare("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE c.book_id = :book_id ORDER BY c.created_at DESC");
        $stmt->bindParam(':book_id', $book_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addComment($book_id, $user_id, $comment) {
        $stmt = $this->conn->prepare("INSERT INTO comments (book_id, user_id, comment) VALUES (:book_id, :user_id, :comment)");
        return $stmt->execute(['book_id' => $book_id, 'user_id' => $user_id, 'comment' => $comment]);
    }
}
?>