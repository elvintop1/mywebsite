<?php
require_once 'config/database.php';

class Contact {
    public $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function saveContact($name, $email, $message) {
        $stmt = $this->conn->prepare("INSERT INTO contacts (name, email, message) VALUES (:name, :email, :message)");
        return $stmt->execute([
            'name' => $name,
            'email' => $email,
            // 'phone' => $phone,
            'message' => $message
        ]);
    }

    public function getAllContacts($page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        $stmt = $this->conn->prepare("SELECT * FROM contacts ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotalContacts() {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM contacts");
        $stmt->execute();
        return $stmt->fetchColumn();
    }
}
?>