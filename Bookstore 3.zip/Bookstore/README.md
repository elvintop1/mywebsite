# BookStore - Website Bán Sách Trực Tuyến

## Tổng Quan

**BookStore** là một website bán sách trực tuyến được xây dựng bằng PHP, sử dụng kiến trúc MVC (Model-View-Controller). Dự án cung cấp các tính năng như hiển thị sách theo danh mục, tìm kiếm sách, thêm sách vào giỏ hàng, quản lý đơn hàng, quản lý tài khoản (người dùng và admin), và trang liên hệ với bản đồ nhúng. Website được thiết kế với giao diện responsive, hiệu suất tối ưu, và bảo mật cơ bản.

### Tính Năng Chính

- **Trang Chủ (**`index.php`**)**:
  - Hiển thị sách nổi bật (bestsellers) và sách theo từng thể loại.
  - Hỗ trợ tìm kiếm sách theo từ khóa.
  - Nút "Add to Cart" để thêm sách vào giỏ hàng ngay từ trang chủ.
- **Trang Tất Cả Sách (**`views/books/all.php`**)**:
  - Hiển thị toàn bộ sách với bộ lọc (theo thể loại, sắp xếp).
  - Thanh tìm kiếm động với kết quả cập nhật bằng AJAX (`views/books/search_results.php`).
  - Nút "Add to Cart" cho mỗi sách, hỗ trợ thêm vào giỏ hàng ngay từ danh sách.
- **Trang Chi Tiết Sách (**`views/books/show.php`**)**:
  - Hiển thị thông tin chi tiết của sách, bao gồm hình ảnh, giá, tác giả.
  - Hỗ trợ thêm vào giỏ hàng và bình luận.
- **Giỏ Hàng và Thanh Toán**:
  - Giao diện giỏ hàng (`views/cart/index.php`).
  - Trang thanh toán (`views/user/checkout.php`).
  - Quản lý đơn hàng (`views/user/order_detail.php`).
- **Quản Lý Tài Khoản (Accounts)**:
  - **Người Dùng (Users)**:
    - Đăng nhập (`views/user/login.php`): Cho phép người dùng đăng nhập vào hệ thống.
    - Đăng ký (`views/user/register.php`): Cho phép người dùng tạo tài khoản mới.
    - Hồ sơ (`views/user/profile.php`): Hiển thị và chỉnh sửa thông tin cá nhân của người dùng.
    - Tạo mật khẩu băm (`views/user/hash_password.php`): Công cụ hỗ trợ tạo mật khẩu băm để tăng bảo mật.
  - **Admin**:
    - Đăng nhập Admin (`views/admin/login.php`): Cho phép admin đăng nhập vào hệ thống quản lý.
    - Quản lý Người Dùng (`views/admin/manage_users.php`): Hiển thị danh sách người dùng, cho phép admin xem và quản lý tài khoản.
    - Thêm Người Dùng (`views/admin/add_user.php`): Giao diện để admin tạo tài khoản người dùng mới.
    - Chỉnh Sửa Người Dùng (`views/admin/edit_user.php`): Giao diện để admin chỉnh sửa thông tin tài khoản người dùng.
- **Trang Liên Hệ (**`views/contact/index.php`**)**:
  - Form liên hệ với các trường Full Name, Email, và Message.
  - Bản đồ nhúng (iframe) hiển thị vị trí "Bitexco Financial Tower" (tối ưu hiệu suất bằng cách không sử dụng Google Maps API).
- **Quản Lý Admin**:
  - Bảng điều khiển admin (`views/admin/dashboard.php`) và super admin (`views/super_admin/dashboard.php`).
  - Quản lý sách: thêm (`views/admin/add_book.php`), chỉnh sửa (`views/admin/edit_book.php`), xóa (`views/admin/delete_book.php`).
  - Quản lý danh mục: thêm (`views/admin/add_category.php`), chỉnh sửa (`views/admin/edit_category.php`), xóa (`views/admin/delete_category.php`), danh sách (`views/admin/manage_categories.php`).
  - Quản lý liên hệ (`views/admin/manage_contacts.php`).
- **Tối Ưu Hiệu Suất**:
  - Sử dụng `loading="lazy"` cho hình ảnh.
  - Loại bỏ Google Maps API, thay bằng iframe nhúng để giảm yêu cầu mạng.

## Yêu Cầu Hệ Thống

Để chạy project này trên máy cục bộ hoặc server, bạn cần đáp ứng các yêu cầu sau:

- **PHP**: Phiên bản 7.4 hoặc cao hơn.
- **Web Server**: Apache hoặc Nginx.
- **MySQL**: Phiên bản 5.7 hoặc cao hơn (để lưu trữ cơ sở dữ liệu sách, giỏ hàng, đơn hàng, v.v.).
- **Trình Duyệt**: Các trình duyệt hiện đại (Chrome, Firefox, Safari, Edge).
- **Thư Viện Bên Ngoài**:
  - Bootstrap 5.3.3 (CSS và JS).
  - Bootstrap Icons 1.11.3.
  - Animate.css 4.1.1.
  - SweetAlert2 11.

## Hướng Dẫn Cài Đặt

### 1. Tải Project

Clone repository từ GitHub (hoặc tải ZIP và giải nén):

```bash
git clone https://github.com/<your-username>/bookstore.git
cd bookstore
```

### 2. Cấu Hình Cơ Sở Dữ Liệu

- Tạo cơ sở dữ liệu MySQL:

  ```sql
  CREATE DATABASE bookstore;
  ```

- Import schema và dữ liệu mẫu từ file `database.sql`:

  ```bash
  mysql -u <username> -p bookstore < database.sql
  ```

- Cập nhật thông tin kết nối cơ sở dữ liệu trong file `config/database.php`:

  ```php
  <?php
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', 'your_password');
  define('DB_NAME', 'bookstore');
  ?>
  ```

### 3. Cấu Hình Web Server

- Đặt thư mục project vào thư mục web server (e.g., `htdocs` nếu dùng XAMPP).

- Đảm bảo `.htaccess` được cấu hình để hỗ trợ URL rewriting (nếu dùng Apache):

  ```apache
  RewriteEngine On
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^(.*)$ index.php?url=$1 [QSA,L]
  ```

### 4. Chạy Project

- Khởi động web server (Apache/Nginx) và MySQL.

- Truy cập website qua trình duyệt:

  ```
  http://localhost/bookstore
  ```

### 5. Kiểm Tra

- Mở trang chủ (`http://localhost/bookstore`) để xem sách nổi bật và sách theo thể loại.
- Truy cập trang tất cả sách (`http://localhost/bookstore/index.php?controller=book&action=all`) để kiểm tra bộ lọc, tìm kiếm, và chức năng "Add to Cart".
- Truy cập trang giỏ hàng (`http://localhost/bookstore/index.php?controller=cart&action=index`) và thanh toán (`http://localhost/bookstore/index.php?controller=user&action=checkout`).
- Kiểm tra quản lý tài khoản:
  - Đăng nhập/đăng ký người dùng (`http://localhost/bookstore/index.php?controller=user&action=login`, `http://localhost/bookstore/index.php?controller=user&action=register`).
  - Xem hồ sơ người dùng (`http://localhost/bookstore/index.php?controller=user&action=profile`).
  - Đăng nhập admin (`http://localhost/bookstore/index.php?controller=admin&action=login`) và quản lý người dùng (`http://localhost/bookstore/index.php?controller=admin&action=manage_users`).
- Truy cập trang liên hệ (`http://localhost/bookstore/index.php?controller=contact`) để kiểm tra form và bản đồ nhúng.

## Cấu Trúc Thư Mục

```
bookstore/
├── config/
│   └── database.php        # Cấu hình kết nối cơ sở dữ liệu
├── controllers/
│   ├── BookController.php  # Điều khiển logic cho sách (hiển thị, tìm kiếm)
│   ├── CartController.php  # Điều khiển logic cho giỏ hàng (thêm, cập nhật)
│   ├── ContactController.php  # Điều khiển logic cho trang liên hệ
│   └── UserController.php  # Điều khiển logic cho người dùng (đăng nhập, đăng ký)
├── css/
│   ├── book-banner.jpg     # Hình ảnh banner cho trang tất cả sách
│   └── style.css           # File CSS tùy chỉnh
├── images/
│   ├── 4326ab...7d7cf.jpg  # Hình ảnh sách (ví dụ)
│   └── 1984.jpg            # Hình ảnh sách (ví dụ)
├── js/
│   └── script.js           # File JavaScript tùy chỉnh (tìm kiếm AJAX, thêm vào giỏ hàng, v.v.)
├── models/
│   ├── Book.php            # Model quản lý sách
│   ├── Cart.php            # Model quản lý giỏ hàng
│   ├── Category.php        # Model quản lý danh mục sách
│   ├── Comment.php         # Model quản lý bình luận
│   ├── Contact.php         # Model quản lý thông tin liên hệ
│   ├── Order.php           # Model quản lý đơn hàng
│   └── User.php            # Model quản lý người dùng
├── views/
│   ├── admin/
│   │   ├── add_book.php       # Giao diện thêm sách
│   │   ├── add_category.php   # Giao diện thêm danh mục
│   │   ├── add_user.php       # Giao diện thêm người dùng
│   │   ├── dashboard.php      # Bảng điều khiển admin
│   │   ├── delete_book.php    # Xóa sách
│   │   ├── delete_category.php  # Xóa danh mục
│   │   ├── edit_book.php      # Giao diện chỉnh sửa sách
│   │   ├── edit_category.php  # Giao diện chỉnh sửa danh mục
│   │   ├── edit_user.php      # Giao diện chỉnh sửa người dùng
│   │   ├── login.php          # Giao diện đăng nhập admin
│   │   ├── manage_categories.php  # Quản lý danh mục
│   │   ├── manage_contacts.php    # Quản lý thông tin liên hệ
│   │   └── manage_users.php       # Quản lý người dùng
│   ├── books/
│   │   ├── all.php            # Trang hiển thị tất cả sách
│   │   ├── detail.php         # Trang chi tiết sách (có thể trùng với show.php)
│   │   ├── search_results.php  # Giao diện kết quả tìm kiếm
│   │   └── show.php           # Trang chi tiết sách
│   ├── cart/
│   │   └── index.php          # Giao diện giỏ hàng
│   ├── contact/
│   │   └── index.php          # Giao diện trang liên hệ
│   ├── layouts/
│   │   ├── admin_header.php   # Header cho các trang admin
│   │   ├── footer.php         # Footer chung cho các trang
│   │   ├── header.php         # Header chung cho các trang người dùng
│   │   └── main.php           # Giao diện chính (có thể không sử dụng)
│   ├── super_admin/
│   │   └── dashboard.php      # Bảng điều khiển super admin
│   └── user/
│       ├── login.php          # Giao diện đăng nhập người dùng
│       ├── order_detail.php   # Giao diện chi tiết đơn hàng
│       ├── profile.php        # Giao diện hồ sơ người dùng
│       ├── register.php       # Giao diện đăng ký người dùng
│       ├── checkout.php       # Giao diện thanh toán
│       ├── hash_password.php  # Tạo mật khẩu băm
│       └── index.php          # Giao diện trang người dùng
├── index.php              # Trang chủ
└── README.md              # File này
```

## Thư Viện Sử Dụng

- **Bootstrap 5.3.3**: Framework CSS/JS cho giao diện responsive.

  ```html
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  ```

- **Bootstrap Icons 1.11.3**: Biểu tượng cho các nút và giao diện.

  ```html
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  ```

- **Animate.css 4.1.1**: Hiệu ứng animation cho các phần tử.

  ```html
  <link href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css" rel="stylesheet">
  ```

- **SweetAlert2 11**: Hiển thị thông báo đẹp mắt.

  ```html
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
  ```

## Ghi Chú

- **Tối Ưu Hiệu Suất**:
  - Sử dụng `loading="lazy"` cho hình ảnh để cải thiện tốc độ tải trang.
  - Loại bỏ Google Maps API trong trang liên hệ, thay bằng iframe nhúng để giảm yêu cầu mạng.
- **Responsive Design**:
  - Website được tối ưu cho cả desktop và mobile (Bootstrap grid system, media queries trong `style.css`).
- **Bảo Mật**:
  - Sử dụng `htmlspecialchars()` để ngăn XSS trong các trường dữ liệu.
  - Sử dụng `filter_var()` để làm sạch dữ liệu đầu vào (e.g., từ khóa tìm kiếm).
  - File `hash_password.php` hỗ trợ tạo mật khẩu băm để tăng bảo mật cho tài khoản.
- **Account**:
    - Super Admin account: admin, pass: admin123
    - Admin account: admin2, pass: 123456
    - User account: elvin12, pass: user123

## Đóng Góp

Nếu bạn muốn đóng góp vào project này:

1. Fork repository.
2. Tạo nhánh mới: `git checkout -b feature/your-feature-name`.
3. Commit thay đổi: `git commit -m "Add your feature"`.
4. Push nhánh: `git push origin feature/your-feature-name`.
5. Tạo Pull Request.